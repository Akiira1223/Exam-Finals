<?php
require_once '../config/cors.php';
require_once '../models/JobModel.php';

try {
    $jobModel = new JobModel();
    
    // Get job statistics with aggregation and grouping
    $stats = $jobModel->getJobStatistics();
    
    echo json_encode([
        'success' => true,
        'statistics' => $stats
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
