<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);
$job_id = $_GET['id'] ?? '';

if (empty($job_id) || !is_numeric($job_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job ID']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] !== 'employer') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only employers can delete jobs']);
        exit();
    }

    // Check if job belongs to user
    $query = "SELECT id FROM jobs WHERE id = :id AND employer_id = :employer_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $job_id);
    $stmt->bindParam(':employer_id', $user['id']);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Job not found or access denied']);
        exit();
    }

    // Delete applications first (foreign key constraint)
    $query = "DELETE FROM applications WHERE job_id = :job_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':job_id', $job_id);
    $stmt->execute();

    // Delete job
    $query = "DELETE FROM jobs WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $job_id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Job deleted successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to delete job']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>