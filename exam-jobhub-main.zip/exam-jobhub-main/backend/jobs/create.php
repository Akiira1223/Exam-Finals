<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit();
}

$title = $input['title'] ?? '';
$company = $input['company'] ?? '';
$location = $input['location'] ?? '';
$type = $input['type'] ?? '';
$description = $input['description'] ?? '';
$salary = $input['salary'] ?? '0';

// Validation
if (empty($title) || empty($company) || empty($location) || empty($type) || empty($description)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
    exit();
}

if (!in_array($type, ['full-time', 'part-time', 'contract', 'remote'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job type']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] !== 'employer') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only employers can post jobs']);
        exit();
    }

    // Insert job
    $query = "INSERT INTO jobs (title, company, location, type, description, salary, employer_id, created_at) 
              VALUES (:title, :company, :location, :type, :description, :salary, :employer_id, NOW())";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':company', $company);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':salary', $salary);
    $stmt->bindParam(':employer_id', $user['id']);

    if ($stmt->execute()) {
        $job_id = $db->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'Job created successfully',
            'job_id' => $job_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create job']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>