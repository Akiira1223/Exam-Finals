<?php
require_once '../config/cors.php';
require_once '../models/JobModel.php';

// Check authentication
$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? '';

if (!preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

$token = $matches[1];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['id']) || !is_numeric($input['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job ID']);
    exit;
}

$jobId = (int)$input['id'];

// Validate required fields
$requiredFields = ['title', 'company', 'location', 'type', 'description'];
foreach ($requiredFields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Missing required field: {$field}"]);
        exit;
    }
}

// Validate job type
$validTypes = ['full-time', 'part-time', 'contract', 'remote'];
if (!in_array($input['type'], $validTypes)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job type']);
    exit;
}

try {
    $jobModel = new JobModel();
    $db = DatabaseConnection::getInstance()->getConnection();
    
    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM sessions s 
              INNER JOIN users u ON s.user_id = u.id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    
    $user = $stmt->fetch();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit;
    }
    
    if ($user['role'] !== 'employer') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only employers can update jobs']);
        exit;
    }
    
    // Verify job belongs to employer
    $job = $jobModel->findById($jobId);
    
    if (!$job) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Job not found']);
        exit;
    }
    
    if ($job['employer_id'] != $user['id']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You can only update your own jobs']);
        exit;
    }
    
    // Update job
    $updateData = [
        'title' => trim($input['title']),
        'company' => trim($input['company']),
        'location' => trim($input['location']),
        'type' => $input['type'],
        'description' => trim($input['description']),
        'salary' => trim($input['salary'] ?? '0')
    ];
    
    $success = $jobModel->update($jobId, $updateData);
    
    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Job updated successfully',
            'job_id' => $jobId
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update job']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
