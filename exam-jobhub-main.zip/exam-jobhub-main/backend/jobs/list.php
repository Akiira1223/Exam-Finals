<?php
require_once '../config/cors.php';
require_once '../config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();

    // Get all jobs with application counts
    $query = "SELECT j.*, 
                     COUNT(a.id) as applications_count
              FROM jobs j
              LEFT JOIN applications a ON j.id = a.job_id
              GROUP BY j.id
              ORDER BY j.created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();

    $jobs = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $jobs[] = [
            'id' => (int)$row['id'],
            'title' => $row['title'],
            'company' => $row['company'],
            'location' => $row['location'],
            'type' => $row['type'],
            'description' => $row['description'],
            'salary' => $row['salary'],
            'employer_id' => (int)$row['employer_id'],
            'created_at' => $row['created_at'],
            'applications_count' => (int)$row['applications_count']
        ];
    }

    echo json_encode([
        'success' => true,
        'jobs' => $jobs
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>