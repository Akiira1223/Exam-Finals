<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);

// Get input
$input = json_decode(file_get_contents('php://input'), true);
$application_id = $input['application_id'] ?? null;
$status = $input['status'] ?? '';

if (!$application_id || !is_numeric($application_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Valid application ID required']);
    exit();
}

if (!in_array($status, ['pending', 'accepted', 'rejected'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid status. Must be: pending, accepted, or rejected']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] !== 'employer') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only employers can update application status']);
        exit();
    }

    // Check if the application is for a job owned by this employer
    $query = "SELECT a.id FROM applications a
              JOIN jobs j ON a.job_id = j.id
              WHERE a.id = :application_id AND j.employer_id = :employer_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':application_id', $application_id);
    $stmt->bindParam(':employer_id', $user['id']);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Application not found or unauthorized']);
        exit();
    }

    // Update the application status
    $query = "UPDATE applications SET status = :status WHERE id = :application_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':application_id', $application_id);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Application status updated successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update application status']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
