<?php
require_once __DIR__ . '/BaseModel.php';

/**
 * Application Model - Demonstrates OOP inheritance
 */
class ApplicationModel extends BaseModel {
    protected $table = 'applications';
    
    /**
     * Get applications with job and user details using INNER JOIN
     * @param int $userId
     * @return array
     */
    public function getApplicationsWithDetails($userId) {
        $query = "SELECT 
                    a.*,
                    j.title as job_title,
                    j.company,
                    j.location,
                    j.type as job_type,
                    j.salary,
                    u.name as employer_name,
                    u.email as employer_email
                  FROM applications a
                  INNER JOIN jobs j ON a.job_id = j.id
                  INNER JOIN users u ON j.employer_id = u.id
                  WHERE a.user_id = :user_id
                  ORDER BY a.applied_at DESC";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Get applications for employer's jobs using INNER JOIN
     * @param int $employerId
     * @return array
     */
    public function getApplicationsForEmployer($employerId) {
        $query = "SELECT 
                    a.*,
                    j.title as job_title,
                    j.company,
                    u.name as applicant_name,
                    u.email as applicant_email
                  FROM applications a
                  INNER JOIN jobs j ON a.job_id = j.id
                  INNER JOIN users u ON a.user_id = u.id
                  WHERE j.employer_id = :employer_id
                  ORDER BY a.applied_at DESC";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':employer_id', $employerId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Update application status
     * @param int $id
     * @param string $status
     * @return bool
     */
    public function updateStatus($id, $status) {
        $query = "UPDATE applications SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    /**
     * Check if user has applied for a job
     * @param int $userId
     * @param int $jobId
     * @return bool
     */
    public function hasApplied($userId, $jobId) {
        $query = "SELECT COUNT(*) as count FROM applications WHERE user_id = :user_id AND job_id = :job_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':job_id', $jobId, PDO::PARAM_INT);
        $stmt->execute();
        
        $result = $stmt->fetch();
        return $result['count'] > 0;
    }
}
?>
