<?php
require_once __DIR__ . '/../database/DatabaseConnection.php';

/**
 * Base Model Class - OOP Implementation
 * Implements common CRUD operations for all models
 */
abstract class BaseModel {
    protected $db;
    protected $table;
    
    public function __construct() {
        $this->db = DatabaseConnection::getInstance()->getConnection();
    }
    
    /**
     * Find record by ID
     * @param int $id
     * @return array|null
     */
    public function findById($id) {
        $query = "SELECT * FROM {$this->table} WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Find all records
     * @param array $options - sorting, filtering, pagination options
     * @return array
     */
    public function findAll($options = []) {
        $query = "SELECT * FROM {$this->table}";
        
        // Add WHERE clause if filters provided
        if (isset($options['where'])) {
            $query .= " WHERE " . $options['where'];
        }
        
        // Add ORDER BY clause if sorting provided
        if (isset($options['orderBy'])) {
            $query .= " ORDER BY " . $options['orderBy'];
            if (isset($options['order'])) {
                $query .= " " . strtoupper($options['order']);
            }
        }
        
        // Add LIMIT clause if pagination provided
        if (isset($options['limit'])) {
            $query .= " LIMIT " . (int)$options['limit'];
            if (isset($options['offset'])) {
                $query .= " OFFSET " . (int)$options['offset'];
            }
        }
        
        $stmt = $this->db->prepare($query);
        
        // Bind parameters if provided
        if (isset($options['params'])) {
            foreach ($options['params'] as $key => $value) {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Create new record
     * @param array $data
     * @return int - last insert ID
     */
    public function create($data) {
        $fields = array_keys($data);
        $values = array_values($data);
        
        $fieldList = implode(', ', $fields);
        $placeholders = implode(', ', array_fill(0, count($fields), '?'));
        
        $query = "INSERT INTO {$this->table} ({$fieldList}) VALUES ({$placeholders})";
        $stmt = $this->db->prepare($query);
        $stmt->execute($values);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update record by ID
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data) {
        $fields = array_keys($data);
        $setClause = implode(' = ?, ', $fields) . ' = ?';
        
        $query = "UPDATE {$this->table} SET {$setClause} WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        $values = array_values($data);
        $values[] = $id;
        
        return $stmt->execute($values);
    }
    
    /**
     * Delete record by ID
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$id]);
    }
    
    /**
     * Count records
     * @param array $options
     * @return int
     */
    public function count($options = []) {
        $query = "SELECT COUNT(*) as count FROM {$this->table}";
        
        if (isset($options['where'])) {
            $query .= " WHERE " . $options['where'];
        }
        
        $stmt = $this->db->prepare($query);
        
        if (isset($options['params'])) {
            foreach ($options['params'] as $key => $value) {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        $result = $stmt->fetch();
        return (int)$result['count'];
    }
}
?>
