<?php
require_once __DIR__ . '/BaseModel.php';

/**
 * Job Model - Implements OOP principles (Inheritance from BaseModel)
 */
class JobModel extends BaseModel {
    protected $table = 'jobs';
    
    /**
     * Get jobs with employer details using INNER JOIN
     * @param array $options
     * @return array
     */
    public function getJobsWithEmployer($options = []) {
        $query = "SELECT 
                    j.*,
                    u.name as employer_name,
                    u.email as employer_email,
                    COUNT(a.id) as applications_count
                  FROM jobs j
                  INNER JOIN users u ON j.employer_id = u.id
                  LEFT JOIN applications a ON j.id = a.job_id";
        
        $conditions = [];
        $params = [];
        
        // Filter by job type
        if (isset($options['type'])) {
            $conditions[] = "j.type = :type";
            $params[':type'] = $options['type'];
        }
        
        // Filter by location
        if (isset($options['location'])) {
            $conditions[] = "j.location LIKE :location";
            $params[':location'] = '%' . $options['location'] . '%';
        }
        
        // Filter by search term
        if (isset($options['search'])) {
            $conditions[] = "(j.title LIKE :search OR j.company LIKE :search OR j.description LIKE :search)";
            $params[':search'] = '%' . $options['search'] . '%';
        }
        
        // Filter by salary range
        if (isset($options['min_salary'])) {
            $conditions[] = "CAST(j.salary AS UNSIGNED) >= :min_salary";
            $params[':min_salary'] = $options['min_salary'];
        }
        
        if (isset($options['max_salary'])) {
            $conditions[] = "CAST(j.salary AS UNSIGNED) <= :max_salary";
            $params[':max_salary'] = $options['max_salary'];
        }
        
        // Add WHERE clause if filters exist
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }
        
        $query .= " GROUP BY j.id";
        
        // Sorting
        $validSortFields = ['j.created_at', 'j.title', 'j.company', 'j.salary', 'applications_count'];
        $sortBy = $options['sortBy'] ?? 'j.created_at';
        $sortOrder = strtoupper($options['sortOrder'] ?? 'DESC');
        
        if (in_array($sortBy, $validSortFields) && in_array($sortOrder, ['ASC', 'DESC'])) {
            $query .= " ORDER BY {$sortBy} {$sortOrder}";
        }
        
        // Pagination
        if (isset($options['limit'])) {
            $query .= " LIMIT :limit";
            if (isset($options['offset'])) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->db->prepare($query);
        
        // Bind all parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        if (isset($options['limit'])) {
            $stmt->bindValue(':limit', (int)$options['limit'], PDO::PARAM_INT);
            if (isset($options['offset'])) {
                $stmt->bindValue(':offset', (int)$options['offset'], PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Get jobs by employer ID
     * @param int $employerId
     * @return array
     */
    public function getJobsByEmployer($employerId) {
        return $this->findAll([
            'where' => 'employer_id = :employer_id',
            'params' => [':employer_id' => $employerId],
            'orderBy' => 'created_at',
            'order' => 'DESC'
        ]);
    }
    
    /**
     * Get job statistics using aggregation
     * @return array
     */
    public function getJobStatistics() {
        $query = "SELECT 
                    COUNT(*) as total_jobs,
                    COUNT(DISTINCT employer_id) as total_employers,
                    AVG(CAST(salary AS UNSIGNED)) as avg_salary,
                    MAX(CAST(salary AS UNSIGNED)) as max_salary,
                    MIN(CAST(salary AS UNSIGNED)) as min_salary,
                    type,
                    COUNT(*) as count_by_type
                  FROM jobs
                  GROUP BY type";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
?>
