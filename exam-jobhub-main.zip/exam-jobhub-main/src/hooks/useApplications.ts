import { useState, useEffect } from 'react';

export interface Application {
  id: number;
  job_id: number;
  user_id: number;
  cover_letter: string;
  status: 'pending' | 'accepted' | 'rejected';
  applied_at: string;
  job_title?: string;
  company?: string;
}

export function useApplications() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchApplications = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/my-applications.php', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      
      if (response.ok && data.success) {
        setApplications(data.applications);
        setError(null);
      } else {
        setError(data.message || 'Failed to fetch applications');
      }
    } catch (err) {
      setError('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const applyForJob = async (jobId: number, coverLetter: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/apply.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ job_id: jobId, cover_letter: coverLetter })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        await fetchApplications();
        return { success: true };
      }
      return { success: false, message: data.message };
    } catch (error) {
      return { success: false, message: 'Failed to submit application' };
    }
  };

  const checkApplicationStatus = async (jobId: number) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost/job-board-api/applications/check.php?job_id=${jobId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      return data.has_applied || false;
    } catch (error) {
      return false;
    }
  };

  const deleteApplication = async (applicationId: number) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/delete.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ application_id: applicationId })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        await fetchApplications();
        return { success: true };
      }
      return { success: false, message: data.message };
    } catch (error) {
      return { success: false, message: 'Failed to delete application' };
    }
  };

  const updateApplicationStatus = async (applicationId: number, status: 'pending' | 'accepted' | 'rejected') => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/update-status.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ application_id: applicationId, status })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        return { success: true };
      }
      return { success: false, message: data.message };
    } catch (error) {
      return { success: false, message: 'Failed to update application status' };
    }
  };

  return {
    applications,
    loading,
    error,
    fetchApplications,
    applyForJob,
    checkApplicationStatus,
    deleteApplication,
    updateApplicationStatus
  };
}
