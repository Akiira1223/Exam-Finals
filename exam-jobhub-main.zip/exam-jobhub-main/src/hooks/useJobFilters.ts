import { useState, useCallback } from 'react';
import { Job } from './useJobs';

export interface JobFilters {
  searchTerm: string;
  location: string;
  jobType: string;
  minSalary: number;
  maxSalary: number;
}

export function useJobFilters(jobs: Job[]) {
  const [filters, setFilters] = useState<JobFilters>({
    searchTerm: '',
    location: '',
    jobType: '',
    minSalary: 0,
    maxSalary: Infinity
  });

  const updateFilter = useCallback((key: keyof JobFilters, value: string | number) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({
      searchTerm: '',
      location: '',
      jobType: '',
      minSalary: 0,
      maxSalary: Infinity
    });
  }, []);

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(filters.searchTerm.toLowerCase());
    const matchesLocation = !filters.location || job.location.toLowerCase().includes(filters.location.toLowerCase());
    const matchesType = !filters.jobType || job.type === filters.jobType;
    const salary = parseInt(job.salary) || 0;
    const matchesSalary = salary >= filters.minSalary && salary <= filters.maxSalary;

    return matchesSearch && matchesLocation && matchesType && matchesSalary;
  });

  return {
    filters,
    updateFilter,
    resetFilters,
    filteredJobs,
    filterCount: Object.values(filters).filter(v => v && v !== 0 && v !== Infinity).length
  };
}
