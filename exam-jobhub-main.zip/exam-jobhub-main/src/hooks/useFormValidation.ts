import { useState, useCallback } from 'react';

type ValidationRules<T> = {
  [K in keyof T]?: {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    pattern?: RegExp;
    custom?: (value: T[K]) => string | null;
  };
};

type ValidationErrors<T> = {
  [K in keyof T]?: string;
};

export function useFormValidation<T extends Record<string, any>>(
  initialValues: T,
  rules: ValidationRules<T>
) {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<ValidationErrors<T>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});

  const validate = useCallback((fieldName: keyof T, value: any): string | null => {
    const fieldRules = rules[fieldName];
    if (!fieldRules) return null;

    if (fieldRules.required && (!value || value.toString().trim() === '')) {
      return 'This field is required';
    }

    if (fieldRules.minLength && value.length < fieldRules.minLength) {
      return `Minimum length is ${fieldRules.minLength}`;
    }

    if (fieldRules.maxLength && value.length > fieldRules.maxLength) {
      return `Maximum length is ${fieldRules.maxLength}`;
    }

    if (fieldRules.pattern && !fieldRules.pattern.test(value)) {
      return 'Invalid format';
    }

    if (fieldRules.custom) {
      return fieldRules.custom(value);
    }

    return null;
  }, [rules]);

  const handleChange = useCallback((fieldName: keyof T, value: any) => {
    setValues(prev => ({ ...prev, [fieldName]: value }));
    
    if (touched[fieldName]) {
      const error = validate(fieldName, value);
      setErrors(prev => ({ ...prev, [fieldName]: error || undefined }));
    }
  }, [touched, validate]);

  const handleBlur = useCallback((fieldName: keyof T) => {
    setTouched(prev => ({ ...prev, [fieldName]: true }));
    const error = validate(fieldName, values[fieldName]);
    setErrors(prev => ({ ...prev, [fieldName]: error || undefined }));
  }, [values, validate]);

  const validateAll = useCallback((): boolean => {
    const newErrors: ValidationErrors<T> = {};
    let isValid = true;

    Object.keys(rules).forEach((key) => {
      const fieldName = key as keyof T;
      const error = validate(fieldName, values[fieldName]);
      if (error) {
        newErrors[fieldName] = error;
        isValid = false;
      }
    });

    setErrors(newErrors);
    setTouched(Object.keys(rules).reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    return isValid;
  }, [rules, values, validate]);

  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
  }, [initialValues]);

  return {
    values,
    errors,
    touched,
    handleChange,
    handleBlur,
    validateAll,
    resetForm,
    setValues
  };
}
