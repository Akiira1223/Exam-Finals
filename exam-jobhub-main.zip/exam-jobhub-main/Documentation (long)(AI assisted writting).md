# JobBoard - A Simple Guide to Everything

---

## What Is This Project?

JobBoard is a complete job posting and application platform - think of it like a mini Indeed or LinkedIn Jobs. It connects two types of users:

- **Job Seekers** - People looking for work who can browse and apply to jobs
- **Employers** - Companies who can post job openings and review applications

---

## ✨What Can You Do With It?

### As a Job Seeker:
1. **Create an account** and log in
2. **Browse available jobs** with filters (job type, location, salary)
3. **Search for specific positions** using keywords
4. **View detailed job descriptions** with company information
5. **Apply to jobs** with one click
6. **Track your applications** in your dashboard

### As an Employer:
1. **Create a company account** and log in
2. **Post new job openings** with all the details
3. **Manage your job listings** (edit, delete)
4. **Review applications** from interested candidates
5. **See statistics** about your postings

---

## 🛠️ How It Works (The Simple Version)

### The Frontend (What You See)
Built with **React** - this is the visual part of the app that runs in your web browser. It's like the storefront of a shop - everything you click, see, and interact with.

**Key Pages:**
- **Home** - Landing page with job search and featured listings
- **Login/Register** - Create account or sign in
- **Dashboard** - Your personal area (different for seekers vs employers)
- **Job Details** - Full information about a specific job
- **Post Job** - Form for employers to create new listings

### The Backend (The Behind-the-Scenes Magic)
Built with **PHP and MySQL** - this is where data gets stored and processed. It's like the warehouse and office of a shop - you don't see it, but it makes everything work.

**What It Handles:**
- User accounts and passwords (securely!)
- All job listings
- Application submissions
- Who posted what and who applied to what

---

##  Project Structure (Where Everything Lives)

```
JobBoard/
├── src/                          # Frontend React code
│   ├── components/              # Reusable UI pieces
│   │   ├── Header.tsx          # Top navigation bar
│   │   ├── JobCard.tsx         # Individual job listing card
│   │   └── ui/                 # Pre-built UI components (buttons, forms, etc.)
│   │
│   ├── pages/                   # Full page components
│   │   ├── Home.tsx            # Main landing page
│   │   ├── Login.tsx           # Sign in page
│   │   ├── Register.tsx        # Sign up page
│   │   ├── Dashboard.tsx       # User dashboard
│   │   ├── JobDetails.tsx      # Single job view
│   │   └── PostJob.tsx         # Create job posting
│   │
│   ├── hooks/                   # Custom React hooks (reusable logic)
│   │   ├── useAuth.ts          # Handle login/logout
│   │   ├── useJobs.ts          # Fetch and manage jobs
│   │   ├── useApplications.ts  # Handle job applications
│   │   └── [12 + more hooks]     # Various utilities
│   │
│   └── contexts/                # Global state management
│       └── AuthContext.tsx     # User authentication state
│
├── backend/                     # PHP backend code
│   ├── auth/                    # Login/register logic
│   ├── jobs/                    # Job CRUD operations
│   ├── applications/            # Application handling
│   ├── models/                  # Database interaction classes
│   └── config/                  # Database and CORS setup
│
└── backend/setup.sql            # Database structure
```

---

##  How Authentication Works


1. **Registration** - You buy a ticket (create account with email/password)
2. **Login** - You show your ticket to enter (server gives you a special token)
3. **Using the App** - You keep your ticket stub (browser stores the token)
4. **Accessing Features** - Staff checks your stub for premium areas (server verifies token)
5. **Logout** - You leave and throw away the stub (token is deleted)

**Security Features:**
- Passwords are **hashed** (scrambled so no one can read them)
- Session tokens expire after time
- Role-based access (seekers can't post jobs, employers can't apply)

---

##  Database Structure (How Data Is Organized)

Imagine four filing cabinets:

### 1. **Users Cabinet** (users table)
Stores everyone's account information:
- ID number (unique identifier)
- Email address
- Password (encrypted!)
- Full name
- Role (seeker or employer)

### 2. **Sessions Cabinet** (sessions table)
Tracks who's currently logged in:
- Session ID (the token we talked about)
- Which user it belongs to
- When it expires

### 3. **Jobs Cabinet** (jobs table)
All job postings:
- Job ID
- Who posted it (employer ID)
- Job title, description, requirements
- Salary, location, type
- When it was posted

### 4. **Applications Cabinet** (applications table)
Records of who applied to what:
- Application ID
- Which job (job ID)
- Which user (seeker ID)
- When they applied
- Status (pending, accepted, rejected)

**How They Connect:**
- Each job knows which employer posted it
- Each application knows which job and which seeker
- Each session knows which user it belongs to

This is called **relational database design** - everything is connected!

---

## Design System


**Colors:**
- Defined in `src/index.css` using CSS variables
- Uses HSL color format (Hue, Saturation, Lightness)
- Supports both light and dark modes automatically

**Components:**
- Built with **shadcn/ui** - a collection of beautiful, accessible components
- Styled with **Tailwind CSS** - utility classes for quick styling
- Everything is responsive (works on phones, tablets, and desktops)

---

## Custom Hooks (Reusable Logic)

Think of hooks as tools in a toolbox. Instead of writing the same code over and over, we create a tool once and reuse it everywhere.

### Authentication Hooks:
- **useAuth** - Handles login, logout, and user state

### Data Management Hooks:
- **useJobs** - Fetches and manages job listings
- **useApplications** - Handles job applications
- **useJobFilters** - Filters jobs by type, location, salary
- **useJobSort** - Sorts jobs by date, salary, etc.

### UI Enhancement Hooks:
- **useDebounce** - Delays search until user stops typing (better performance)
- **useDocumentTitle** - Updates page title dynamically
- **useClickOutside** - Detects clicks outside a component (for closing menus)
- **useKeyPress** - Responds to keyboard shortcuts
- **useWindowSize** - Tracks screen size for responsive design

### Utility Hooks:
- **useLocalStorage** - Saves data to browser (remembers preferences)
- **usePagination** - Handles page navigation for large lists
- **useFormValidation** - Validates form inputs
- **useAsync** - Manages loading states for async operations

**Total: 15+ custom hooks!**

---

## How Data Flows (The Journey of a Job Application)

Let's follow what happens when a job seeker applies to a job:

### Step 1: User Clicks "Apply"
```
JobCard component → onClick event triggered
```

### Step 2: Frontend Sends Request
```
useApplications hook → Fetch API call to backend
                     → Includes auth token for security
```

### Step 3: Backend Validates
```
backend/applications/apply.php → Checks if user is logged in
                               → Checks if they haven't already applied
                               → Verifies job exists
```

### Step 4: Database Saves
```
ApplicationModel class → Inserts new record into applications table
                       → Uses INNER JOIN to fetch job details
```

### Step 5: Response Returns
```
Backend sends success → Frontend updates UI
                      → Shows success toast notification
                      → Disables apply button
```

### Step 6: Dashboard Updates
```
User navigates to dashboard → useApplications fetches their applications
                            → Shows the new application in the list
```

---

##  Event-Driven Programming (Making Things Interactive)

Events are what make the app respond to user actions. Here are the ones we use:

### Click Events (onClick)
When you click buttons:
- **Apply to Job** - Submits application
- **Delete Job** - Removes a job posting
- **Logout** - Ends your session
- **Navigate** - Goes to different pages

### Double Click (onDoubleClick)
When you double-click a job card:
- Opens the full job details page
- Faster navigation for power users

### Form Events (onSubmit)
When you submit forms:
- **Login Form** - Authenticates user
- **Register Form** - Creates new account
- **Post Job Form** - Creates job listing

### Focus Events (onFocus, onBlur)
When you click into/out of input fields:
- **onFocus** - Clears error messages when you start typing
- **onBlur** - Validates input when you leave the field

### Keyboard Events (onKeyDown, onKeyPress)
When you press keys:
- **Enter on Search** - Triggers search
- **Escape** - Closes modals/dialogs
- **Arrow Keys** - Navigate through lists

### Load Events (onLoad)
When pages or images finish loading:
- Tracks when app is fully loaded
- Shows loading states while waiting

### Change Events (onChange)
When you type or select something:
- **Search Input** - Updates search results live
- **Filters** - Refines job listings
- **Form Fields** - Updates form state

---

##  Object-Oriented Programming in Backend

The backend uses OOP (Object-Oriented Programming) - a way to organize code into reusable "objects" or classes.

### The Class Hierarchy:

```
DatabaseConnection (Singleton)
       ↓
   BaseModel (Parent Class)
       ↓
   ├─── JobModel (Child)
   └─── ApplicationModel (Child)
```

### What Each Does:

**DatabaseConnection** - The Gatekeeper
- Manages one single connection to the database
- Singleton pattern = only one instance ever exists
- Everyone shares this one connection (efficient!)

**BaseModel** - The Template
- Provides basic CRUD operations (Create, Read, Update, Delete)
- Like a blueprint that other models inherit
- Has methods like `findById()`, `findAll()`, `create()`, `update()`, `delete()`

**JobModel** - The Specialist for Jobs
- Inherits all BaseModel methods
- Adds job-specific methods like:
  - `getJobsWithEmployer()` - Gets jobs with company info
  - `getJobStatistics()` - Calculates job stats

**ApplicationModel** - The Specialist for Applications
- Inherits all BaseModel methods
- Adds application-specific methods like:
  - `getApplicationsWithDetails()` - Gets applications with job info
  - `hasApplied()` - Checks if user already applied

**Why This Is Good:**
- Write common code once (in BaseModel)
- Reuse it everywhere (in child models)
- Easy to add new models (just extend BaseModel)
- Clean, organized, maintainable

---

## INNER JOIN (Connecting Related Data)

INNER JOIN is how we combine data from multiple tables. Think of it like merging information from different filing cabinets.

### Example: Getting Jobs with Employer Names

**Without INNER JOIN** (Bad):
```
1. Fetch job from jobs table → Get employer_id
2. Fetch user from users table → Get employer name
3. Do this for every job (slow!)
```

**With INNER JOIN** (Good):
```sql
SELECT jobs.*, users.name as employer_name 
FROM jobs 
INNER JOIN users ON jobs.employer_id = users.id
```
Gets everything in one efficient query!

### Where We Use INNER JOIN:

1. **Job Listings** - Show job + employer name
2. **Applications List** - Show application + job details + company name
3. **Employer Dashboard** - Show applications + job info + applicant details
4. **Session Authentication** - Verify token + get user info

---

##  CRUD Operations (The Four Basic Actions)

CRUD = Create, Read, Update, Delete - the fundamental operations for any data:

### Jobs:
- **Create** - Employer posts a new job (`backend/jobs/create.php`)
- **Read** - Anyone views job listings (`backend/jobs/list.php`)
- **Update** - Employer edits their job (`backend/jobs/update.php`)
- **Delete** - Employer removes their job (`backend/jobs/delete.php`)

### Applications:
- **Create** - Seeker applies to job (`backend/applications/apply.php`)
- **Read** - View your applications (`backend/applications/my-applications.php`)
- **Update** - Employer changes status (pending → accepted)
- **Delete** - Automatically deleted when job is removed

### Users:
- **Create** - New user registers (`backend/auth/register.php`)
- **Read** - Check authentication (`backend/auth/check.php`)
- **Update** - (Not implemented yet, could be profile editing)
- **Delete** - (Not implemented yet, could be account deletion)

---

##  Sorting & Filtering

### Frontend Filtering (Instant):
Uses `useJobFilters` hook to filter jobs in real-time:
- Type (Full-time, Part-time, Contract, Internship)
- Location (city or remote)
- Salary range (minimum to maximum)
- Search keywords (in title or description)

### Frontend Sorting:
Uses `useJobSort` hook to reorder jobs:
- By date (newest first, oldest first)
- By salary (highest first, lowest first)
- By title (alphabetical)

### Backend Filtering:
The `backend/jobs/list-filtered.php` endpoint does server-side filtering:
```php
WHERE job_type = 'Full-time' 
  AND location LIKE '%New York%'
  AND salary >= 50000
  AND (title LIKE '%developer%' OR description LIKE '%developer%')
ORDER BY created_at DESC
LIMIT 10 OFFSET 0
```

**Why Both?**
- Frontend filtering = instant feedback, no server load
- Backend filtering = handles large datasets, can search all records

---

##  How to Set Up and Run

### Prerequisites:
- **Node.js** (v16 or higher) - for running the frontend
- **PHP** (v8 or higher) - for running the backend
- **MySQL** (v8 or higher) - for the database
- **Web Server** (Apache with XAMPP/WAMP, or PHP built-in server)

### Step 1: Database Setup
```sql
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Create a new database called "jobboard"
3. Import the file: backend/setup.sql
4. Done! Tables created automatically
```

### Step 2: Backend Configuration
```php
1. Open backend/config/database.php
2. Update these if needed:
   - DB_HOST (usually localhost)
   - DB_USER (usually root)
   - DB_PASS (your MySQL password)
   - DB_NAME (jobboard)
```

### Step 3: Frontend Setup
```bash
1. Open terminal in project folder
2. Run: npm install (installs all dependencies)
3. Run: npm run dev (starts the development server)
4. Open: http://localhost:8080 in your browser
```

### Step 4: Start Backend Server
```bash
# Option 1: If using XAMPP/WAMP
Just start Apache in control panel

# Option 2: PHP built-in server
cd backend
php -S localhost:8000
```

### Step 5: Test It Out!
1. Go to http://localhost:5173
2. Register a new account
3. Create a job or browse listings
4. Apply to jobs
5. Check your dashboard

---

##  Key Programming Concepts Used

This project demonstrates many important programming concepts:

### 1. **Component-Based Architecture**
- Small, reusable pieces (components) instead of one big file
- Each component has one job and does it well

### 2. **State Management**
- React hooks manage local state (useState)
- Context API manages global state (AuthContext)
- Backend sessions maintain server state

### 3. **Separation of Concerns**
- Frontend handles display and user interaction
- Backend handles data and business logic
- Database stores information persistently

### 4. **RESTful API Design**
- Predictable URL patterns (`/jobs/list`, `/jobs/create`)
- Standard HTTP methods (GET, POST, PUT, DELETE)
- JSON data format for requests/responses

### 5. **Security Best Practices**
- Password hashing (bcrypt)
- SQL injection prevention (prepared statements)
- CORS configuration (cross-origin resource sharing)
- Token-based authentication

### 6. **Responsive Design**
- Mobile-first approach
- Tailwind breakpoints (sm, md, lg, xl)
- Touch-friendly interactions

### 7. **Code Reusability**
- Custom hooks for logic
- Base classes for database operations
- Utility functions in lib/utils.ts

### 8. **Error Handling**
- Try-catch blocks
- User-friendly error messages
- Loading states for async operations

---

##  Common Issues and Solutions

### "Cannot connect to database"
- Check MySQL is running
- Verify database credentials in `backend/config/database.php`
- Ensure "jobboard" database exists

### "CORS error"
- Make sure `backend/config/cors.php` is included in API files
- Check that frontend URL matches allowed origins

### "Token expired"
- Normal behavior after 24 hours
- Just log in again
- Session expired for security

### "Already applied to this job"
- System prevents duplicate applications
- Check dashboard to see existing application

### "Unauthorized access"
- You need to log in
- Token might be invalid or expired
- Check if you're using the right role (seeker vs employer)

---

##  Technologies Explained

### Frontend Stack:

**React 18**
- JavaScript library for building user interfaces
- Component-based = build complex UIs from small pieces
- Virtual DOM = fast updates and rendering

**TypeScript**
- JavaScript with types
- Catches errors before you run the code
- Better autocomplete and documentation

**Vite**
- Modern build tool
- Super fast development server
- Hot module replacement (changes appear instantly)

**Tailwind CSS**
- Utility-first CSS framework
- Write styles directly in HTML
- No need to write custom CSS files

**React Router DOM**
- Navigation for single-page apps
- Different URLs for different pages
- Browser history management

**shadcn/ui**
- Collection of reusable components
- Built on Radix UI (accessibility)
- Customizable and beautiful

### Backend Stack:

**PHP 8+**
- Server-side scripting language
- Processes requests and returns data
- Connects to database

**MySQL**
- Relational database management system
- Stores all application data
- SQL queries to retrieve/modify data

**PDO (PHP Data Objects)**
- Database abstraction layer
- Works with multiple database types
- Prevents SQL injection attacks


---

## 📝 Final Notes

### What You've Built:
A full-stack, production-ready job board application with modern architecture, secure authentication, and beautiful design.

### Skills Demonstrated:
- Frontend development (React, TypeScript)
- Backend development (PHP, MySQL)
- Database design and optimization
- Object-oriented programming
- RESTful API design
- Security best practices
- Responsive UI/UX design
- State management
- Custom hooks creation
- Event-driven programming

### Project Stats:
- **Frontend Files:** 80+ components, hooks, and pages
- **Backend Files:** 15+ API endpoints and models
- **Database Tables:** 4 with relationships
- **Custom Hooks:** 15
- **Event Handlers:** 8 types across multiple components
- **Lines of Code:** 3000+ (excluding dependencies)

---

## 🎉 Conclusion

Congratulations! You now understand every part of this JobBoard project - from how users see and interact with it, to how data flows behind the scenes, to how everything is organized in code.


