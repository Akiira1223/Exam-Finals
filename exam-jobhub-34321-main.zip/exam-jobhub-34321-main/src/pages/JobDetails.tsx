import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Job } from '@/hooks/useJobs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Clock, DollarSign, Building, Calendar, ArrowLeft, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function JobDetails() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [coverLetter, setCoverLetter] = useState('');
  const [applying, setApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);

  useEffect(() => {
    if (id) {
      fetchJobDetails();
      if (user && user.role === 'seeker') {
        checkApplicationStatus();
      }
    }
  }, [id, user]);

  const fetchJobDetails = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost/job-board-api/jobs/details.php?id=${id}`);
      const data = await response.json();
      
      if (response.ok && data.success) {
        setJob(data.job);
        setError(null);
      } else {
        setError(data.message || 'Job not found');
      }
    } catch (err) {
      setError('Failed to load job details');
    } finally {
      setLoading(false);
    }
  };

  const checkApplicationStatus = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost/job-board-api/applications/check.php?job_id=${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      if (response.ok && data.success) {
        setHasApplied(data.has_applied);
      }
    } catch (error) {
      console.error('Failed to check application status:', error);
    }
  };

  const handleApply = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to apply for jobs.",
        variant: "destructive",
      });
      return;
    }

    if (!coverLetter.trim()) {
      toast({
        title: "Cover letter required",
        description: "Please write a cover letter for your application.",
        variant: "destructive",
      });
      return;
    }

    setApplying(true);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/apply.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          job_id: id,
          cover_letter: coverLetter
        })
      });

      const data = await response.json();
      
      if (response.ok && data.success) {
        toast({
          title: "Application submitted!",
          description: "Your application has been sent to the employer.",
        });
        setHasApplied(true);
        setCoverLetter('');
      } else {
        toast({
          title: "Application failed",
          description: data.message || "Failed to submit application.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Network error occurred while submitting application.",
        variant: "destructive",
      });
    } finally {
      setApplying(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="mt-4 text-muted-foreground">Loading job details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Alert className="border-destructive/20 bg-destructive/5">
            <AlertDescription className="text-destructive">
              {error || 'Job not found'}
            </AlertDescription>
          </Alert>
          <div className="mt-6">
            <Link to="/">
              <Button variant="outline" className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Jobs</span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getJobTypeColor = (type: string) => {
    switch (type) {
      case 'full-time': return 'bg-primary/10 text-primary border-primary/20';
      case 'part-time': return 'bg-warning/10 text-warning border-warning/20';
      case 'contract': return 'bg-success/10 text-success border-success/20';
      case 'remote': return 'bg-accent text-accent-foreground border-border';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const formatSalary = (salary: string) => {
    if (!salary || salary === '0') return 'Salary not specified';
    return `$${salary}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link to="/">
            <Button variant="outline" className="flex items-center space-x-2 mb-6">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Jobs</span>
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Job Details */}
          <div className="lg:col-span-2">
            <Card className="p-8 bg-gradient-card shadow-lg">
              <div className="mb-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-foreground mb-2">{job.title}</h1>
                    <div className="flex items-center text-muted-foreground text-lg mb-3">
                      <Building className="w-5 h-5 mr-2" />
                      <span className="font-medium">{job.company}</span>
                    </div>
                  </div>
                  <Badge className={`${getJobTypeColor(job.type)} font-medium text-sm`}>
                    {job.type.replace('-', ' ')}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span>{job.location}</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <DollarSign className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span>{formatSalary(job.salary)}</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span>Posted {new Date(job.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold text-foreground mb-4">Job Description</h2>
                <div className="prose prose-sm max-w-none text-muted-foreground">
                  <p className="whitespace-pre-wrap leading-relaxed">{job.description}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Application Panel */}
          <div>
            <Card className="p-6 bg-gradient-card shadow-lg sticky top-24">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                {user?.role === 'employer' ? 'Job Actions' : 'Apply for this Job'}
              </h3>

              {!user ? (
                <div className="text-center space-y-4">
                  <p className="text-muted-foreground text-sm">
                    Sign in to apply for this position
                  </p>
                  <div className="space-y-2">
                    <Link to="/login">
                      <Button className="w-full bg-gradient-button hover:opacity-90">
                        Sign In
                      </Button>
                    </Link>
                    <Link to="/register">
                      <Button variant="outline" className="w-full">
                        Create Account
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : user.role === 'employer' ? (
                <div className="space-y-4">
                  {job.employer_id === user.id ? (
                    <div>
                      <p className="text-sm text-muted-foreground mb-4">
                        This is your job posting
                      </p>
                      <Link to="/dashboard">
                        <Button variant="outline" className="w-full">
                          Manage in Dashboard
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      This job was posted by another employer
                    </p>
                  )}
                </div>
              ) : hasApplied ? (
                <div className="text-center space-y-4">
                  <div className="w-12 h-12 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                    <Send className="w-6 h-6 text-success" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Application Submitted</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      You have already applied for this position
                    </p>
                  </div>
                  <Link to="/dashboard">
                    <Button variant="outline" className="w-full">
                      View Application
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="coverLetter" className="text-sm font-medium text-foreground">
                      Cover Letter *
                    </Label>
                    <Textarea
                      id="coverLetter"
                      placeholder="Write a compelling cover letter explaining why you're perfect for this role..."
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      className="mt-2 min-h-[120px]"
                    />
                  </div>
                  
                  <Button 
                    onClick={handleApply}
                    disabled={applying}
                    className="w-full bg-gradient-button hover:opacity-90"
                  >
                    {applying ? 'Submitting...' : 'Submit Application'}
                  </Button>
                  
                  <p className="text-xs text-muted-foreground text-center">
                    Your application will be sent directly to the employer
                  </p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}