import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useJobs } from '@/hooks/useJobs';
import { Header } from '@/components/Header';
import { JobCard } from '@/components/JobCard';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Briefcase, FileText, Users, TrendingUp, Plus, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useApplications } from '@/hooks/useApplications';

interface Application {
  id: number;
  job_id?: number;
  job_title: string;
  company: string;
  cover_letter: string;
  status: 'pending' | 'accepted' | 'rejected';
  applied_at: string;
  applicant_name?: string;
  applicant_email?: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { jobs, loading, deleteJob, fetchJobs } = useJobs();
  const { deleteApplication, updateApplicationStatus } = useApplications();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [applications, setApplications] = useState<Application[]>([]);
  const [employerApplications, setEmployerApplications] = useState<Application[]>([]);
  const [loadingApplications, setLoadingApplications] = useState(true);

  const userJobs = jobs.filter(job => user?.role === 'employer' && job.employer_id === user.id);

  useEffect(() => {
    if (user?.role === 'seeker') {
      fetchApplications();
    } else if (user?.role === 'employer') {
      fetchEmployerApplications();
    } else {
      setLoadingApplications(false);
    }
  }, [user]);

  useEffect(() => {
    if (user?.role === 'employer') {
      fetchJobs();
    }
  }, [user]);

  const fetchApplications = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/my-applications.php', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      if (response.ok && data.success) {
        setApplications(data.applications);
      }
    } catch (error) {
      console.error('Failed to fetch applications:', error);
    } finally {
      setLoadingApplications(false);
    }
  };

  const fetchEmployerApplications = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/applications/employer-applications.php', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      if (response.ok && data.success) {
        setEmployerApplications(data.applications);
      }
    } catch (error) {
      console.error('Failed to fetch employer applications:', error);
    } finally {
      setLoadingApplications(false);
    }
  };

  const handleDeleteJob = async (jobId: number) => {
    const success = await deleteJob(jobId);
    if (success) {
      toast({
        title: "Job deleted",
        description: "The job posting has been successfully removed.",
      });
    } else {
      toast({
        title: "Error",
        description: "Failed to delete job posting.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteApplication = async (applicationId: number) => {
    const result = await deleteApplication(applicationId);
    if (result.success) {
      toast({
        title: "Application deleted",
        description: "Your application has been successfully removed.",
      });
      fetchApplications();
    } else {
      toast({
        title: "Error",
        description: result.message || "Failed to delete application.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateStatus = async (applicationId: number, status: 'accepted' | 'rejected') => {
    const result = await updateApplicationStatus(applicationId, status);
    if (result.success) {
      toast({
        title: "Status updated",
        description: `Application has been ${status}.`,
      });
      fetchEmployerApplications();
    } else {
      toast({
        title: "Error",
        description: result.message || "Failed to update application status.",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted': return 'bg-success/10 text-success border-success/20';
      case 'rejected': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-warning/10 text-warning border-warning/20';
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Welcome back, {user.name}!
          </h1>
          <p className="text-muted-foreground">
            {user.role === 'employer' 
              ? 'Manage your job postings and review applications' 
              : 'Track your applications and discover new opportunities'
            }
          </p>
        </div>

        {user.role === 'employer' ? (
          <Tabs defaultValue="jobs" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="jobs">My Job Postings</TabsTrigger>
              <TabsTrigger value="applications">Applications</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="jobs">
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-semibold text-foreground">Your Job Postings</h2>
                  <Link to="/post-job">
                    <Button className="bg-gradient-button hover:opacity-90 flex items-center space-x-2">
                      <Plus className="w-4 h-4" />
                      <span>Post New Job</span>
                    </Button>
                  </Link>
                </div>

                {loading ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    <p className="mt-4 text-muted-foreground">Loading your jobs...</p>
                  </div>
                ) : userJobs.length === 0 ? (
                  <Card className="p-12 text-center bg-gradient-card">
                    <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">No job postings yet</h3>
                    <p className="text-muted-foreground mb-6">Start by creating your first job posting</p>
                    <Link to="/post-job">
                      <Button className="bg-gradient-button hover:opacity-90">
                        Post Your First Job
                      </Button>
                    </Link>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {userJobs.map((job) => (
                      <JobCard 
                        key={job.id} 
                        job={job} 
                        showActions={true}
                        onDelete={handleDeleteJob}
                      />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="applications">
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-foreground">Applications Received</h2>

                {loadingApplications ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    <p className="mt-4 text-muted-foreground">Loading applications...</p>
                  </div>
                ) : employerApplications.length === 0 ? (
                  <Card className="p-12 text-center bg-gradient-card">
                    <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">No applications yet</h3>
                    <p className="text-muted-foreground">Applications will appear here when job seekers apply to your jobs</p>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {employerApplications.map((application) => (
                      <Card key={application.id} className="p-6 bg-gradient-card">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-foreground mb-1">
                              {application.job_title}
                            </h3>
                            <p className="text-sm text-muted-foreground mb-2">{application.company}</p>
                            <div className="flex items-center gap-2 text-sm">
                              <span className="font-medium text-foreground">Applicant:</span>
                              <span className="text-muted-foreground">{application.applicant_name}</span>
                              <span className="text-muted-foreground">({application.applicant_email})</span>
                            </div>
                          </div>
                          <Badge className={getStatusColor(application.status)}>
                            {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                          </Badge>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-muted-foreground mb-2">Cover Letter:</p>
                          <p className="text-sm text-foreground bg-muted/30 p-3 rounded-md">
                            {application.cover_letter}
                          </p>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            Applied on {new Date(application.applied_at).toLocaleDateString()}
                          </p>
                          
                          {application.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleUpdateStatus(application.id, 'accepted')}
                                className="text-success border-success/20 hover:bg-success/10"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Accept
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleUpdateStatus(application.id, 'rejected')}
                                className="text-destructive border-destructive/20 hover:bg-destructive/10"
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Reject
                              </Button>
                            </div>
                          )}
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="analytics">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="p-6 bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Jobs</p>
                      <p className="text-2xl font-bold text-foreground">{userJobs.length}</p>
                    </div>
                    <Briefcase className="w-8 h-8 text-primary" />
                  </div>
                </Card>
                
                <Card className="p-6 bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Applications</p>
                      <p className="text-2xl font-bold text-foreground">
                        {userJobs.reduce((sum, job) => sum + (job.applications_count || 0), 0)}
                      </p>
                    </div>
                    <Users className="w-8 h-8 text-success" />
                  </div>
                </Card>

                <Card className="p-6 bg-gradient-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Avg. Applications</p>
                      <p className="text-2xl font-bold text-foreground">
                        {userJobs.length > 0 
                          ? Math.round(userJobs.reduce((sum, job) => sum + (job.applications_count || 0), 0) / userJobs.length)
                          : 0
                        }
                      </p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-warning" />
                  </div>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <Tabs defaultValue="applications" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="applications">My Applications</TabsTrigger>
              <TabsTrigger value="browse">Browse Jobs</TabsTrigger>
            </TabsList>

            <TabsContent value="applications">
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-foreground">Your Applications</h2>

                {loadingApplications ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    <p className="mt-4 text-muted-foreground">Loading your applications...</p>
                  </div>
                ) : applications.length === 0 ? (
                  <Card className="p-12 text-center bg-gradient-card">
                    <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">No applications yet</h3>
                    <p className="text-muted-foreground mb-6">Start applying to jobs that interest you</p>
                    <Link to="/">
                      <Button className="bg-gradient-button hover:opacity-90">
                        Browse Jobs
                      </Button>
                    </Link>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {applications.map((application) => (
                      <Card key={application.id} className="p-6 bg-gradient-card">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-1">
                              {application.job_title}
                            </h3>
                            <p className="text-muted-foreground">{application.company}</p>
                          </div>
                          <Badge className={getStatusColor(application.status)}>
                            {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                          </Badge>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-muted-foreground mb-2">Cover Letter:</p>
                          <p className="text-sm text-foreground bg-muted/30 p-3 rounded-md">
                            {application.cover_letter}
                          </p>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            Applied on {new Date(application.applied_at).toLocaleDateString()}
                          </p>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteApplication(application.id)}
                            className="text-destructive border-destructive/20 hover:bg-destructive/10"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="browse">
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  Ready to find your next opportunity?
                </p>
                <Link to="/">
                  <Button className="bg-gradient-button hover:opacity-90">
                    Browse All Jobs
                  </Button>
                </Link>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}