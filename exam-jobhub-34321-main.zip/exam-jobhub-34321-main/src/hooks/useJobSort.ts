import { useState, useMemo } from 'react';
import { Job } from './useJobs';

export type SortField = 'title' | 'company' | 'location' | 'salary' | 'created_at';
export type SortOrder = 'asc' | 'desc';

export function useJobSort(jobs: Job[]) {
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const sortedJobs = useMemo(() => {
    return [...jobs].sort((a, b) => {
      let aValue: any = a[sortField];
      let bValue: any = b[sortField];

      // Handle salary as number
      if (sortField === 'salary') {
        aValue = parseInt(a.salary) || 0;
        bValue = parseInt(b.salary) || 0;
      }

      // Handle dates
      if (sortField === 'created_at') {
        aValue = new Date(a.created_at).getTime();
        bValue = new Date(b.created_at).getTime();
      }

      // String comparison
      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [jobs, sortField, sortOrder]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  return {
    sortedJobs,
    sortField,
    sortOrder,
    toggleSort,
    setSortField,
    setSortOrder
  };
}
