import { useState, useEffect } from 'react';

export interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract' | 'remote';
  description: string;
  salary: string;
  employer_id: number;
  created_at: string;
  applications_count?: number;
}

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchJobs = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost/job-board-api/jobs/list.php');
      const data = await response.json();
      
      if (response.ok && data.success) {
        setJobs(data.jobs);
        setError(null);
      } else {
        setError(data.message || 'Failed to fetch jobs');
      }
    } catch (err) {
      setError('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const createJob = async (jobData: Omit<Job, 'id' | 'employer_id' | 'created_at'>) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost/job-board-api/jobs/create.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(jobData)
      });

      const data = await response.json();
      if (response.ok && data.success) {
        await fetchJobs(); // Refresh the list
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to create job:', error);
      return false;
    }
  };

  const deleteJob = async (jobId: number) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost/job-board-api/jobs/delete.php?id=${jobId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      if (response.ok && data.success) {
        await fetchJobs(); // Refresh the list
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to delete job:', error);
      return false;
    }
  };

  return {
    jobs,
    loading,
    error,
    fetchJobs,
    createJob,
    deleteJob
  };
}