import { Link } from 'react-router-dom';
import { Job } from '@/hooks/useJobs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, DollarSign, Building } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface JobCardProps {
  job: Job;
  onDelete?: (jobId: number) => void;
  showActions?: boolean;
}

export function JobCard({ job, onDelete, showActions = false }: JobCardProps) {
  const { user } = useAuth();
  
  const handleDoubleClick = () => {
    window.open(`/jobs/${job.id}`, '_blank');
  };
  
  const formatSalary = (salary: string) => {
    if (!salary || salary === '0') return 'Salary not specified';
    return `$${salary}`;
  };

  const getJobTypeColor = (type: string) => {
    switch (type) {
      case 'full-time': return 'bg-primary/10 text-primary border-primary/20';
      case 'part-time': return 'bg-warning/10 text-warning border-warning/20';
      case 'contract': return 'bg-success/10 text-success border-success/20';
      case 'remote': return 'bg-accent text-accent-foreground border-border';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Card 
      className="p-6 hover:shadow-card transition-all duration-200 hover:translate-y-[-2px] border border-border bg-gradient-card cursor-pointer"
      onDoubleClick={handleDoubleClick}
      title="Double-click to open in new tab"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <Link 
            to={`/jobs/${job.id}`}
            className="block group"
          >
            <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors mb-1">
              {job.title}
            </h3>
          </Link>
          <div className="flex items-center text-muted-foreground text-sm mb-2">
            <Building className="w-4 h-4 mr-1" />
            <span className="font-medium">{job.company}</span>
          </div>
        </div>
        
        <Badge className={`${getJobTypeColor(job.type)} font-medium`}>
          {job.type.replace('-', ' ')}
        </Badge>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-center text-sm text-muted-foreground">
          <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
          <span>{job.location}</span>
        </div>
        
        <div className="flex items-center text-sm text-muted-foreground">
          <DollarSign className="w-4 h-4 mr-2 flex-shrink-0" />
          <span>{formatSalary(job.salary)}</span>
        </div>

        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
          <span>Posted {formatDate(job.created_at)}</span>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
        {job.description}
      </p>

      <div className="flex justify-between items-center">
        <Link to={`/jobs/${job.id}`}>
          <Button variant="outline" size="sm" className="hover:bg-primary hover:text-primary-foreground">
            View Details
          </Button>
        </Link>
        
        {showActions && user && user.role === 'employer' && (
          <div className="flex space-x-2">
            {job.applications_count !== undefined && (
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                {job.applications_count} applications
              </span>
            )}
            <Button 
              variant="destructive" 
              size="sm"
              onClick={() => onDelete?.(job.id)}
            >
              Delete
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}