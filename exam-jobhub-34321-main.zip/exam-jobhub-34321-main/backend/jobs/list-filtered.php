<?php
require_once '../config/cors.php';
require_once '../models/JobModel.php';

try {
    $jobModel = new JobModel();
    
    // Get query parameters for filtering and sorting
    $options = [];
    
    if (isset($_GET['type']) && !empty($_GET['type'])) {
        $options['type'] = $_GET['type'];
    }
    
    if (isset($_GET['location']) && !empty($_GET['location'])) {
        $options['location'] = $_GET['location'];
    }
    
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $options['search'] = $_GET['search'];
    }
    
    if (isset($_GET['min_salary']) && is_numeric($_GET['min_salary'])) {
        $options['min_salary'] = (int)$_GET['min_salary'];
    }
    
    if (isset($_GET['max_salary']) && is_numeric($_GET['max_salary'])) {
        $options['max_salary'] = (int)$_GET['max_salary'];
    }
    
    // Sorting parameters
    if (isset($_GET['sortBy'])) {
        $options['sortBy'] = $_GET['sortBy'];
    }
    
    if (isset($_GET['sortOrder'])) {
        $options['sortOrder'] = $_GET['sortOrder'];
    }
    
    // Pagination parameters
    if (isset($_GET['limit']) && is_numeric($_GET['limit'])) {
        $options['limit'] = (int)$_GET['limit'];
    }
    
    if (isset($_GET['offset']) && is_numeric($_GET['offset'])) {
        $options['offset'] = (int)$_GET['offset'];
    }
    
    // Get jobs with filters, sorting, and pagination using INNER JOIN
    $jobs = $jobModel->getJobsWithEmployer($options);
    
    // Format response
    $formattedJobs = array_map(function($job) {
        return [
            'id' => (int)$job['id'],
            'title' => $job['title'],
            'company' => $job['company'],
            'location' => $job['location'],
            'type' => $job['type'],
            'description' => $job['description'],
            'salary' => $job['salary'],
            'employer_id' => (int)$job['employer_id'],
            'employer_name' => $job['employer_name'],
            'employer_email' => $job['employer_email'],
            'created_at' => $job['created_at'],
            'applications_count' => (int)$job['applications_count']
        ];
    }, $jobs);
    
    echo json_encode([
        'success' => true,
        'jobs' => $formattedJobs,
        'count' => count($formattedJobs),
        'filters_applied' => $options
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
