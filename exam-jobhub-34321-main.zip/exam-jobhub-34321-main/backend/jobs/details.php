<?php
require_once '../config/cors.php';
require_once '../config/database.php';

$job_id = $_GET['id'] ?? '';

if (empty($job_id) || !is_numeric($job_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job ID']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Get job details
    $query = "SELECT * FROM jobs WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $job_id);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Job not found']);
        exit();
    }

    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'job' => [
            'id' => (int)$job['id'],
            'title' => $job['title'],
            'company' => $job['company'],
            'location' => $job['location'],
            'type' => $job['type'],
            'description' => $job['description'],
            'salary' => $job['salary'],
            'employer_id' => (int)$job['employer_id'],
            'created_at' => $job['created_at']
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>