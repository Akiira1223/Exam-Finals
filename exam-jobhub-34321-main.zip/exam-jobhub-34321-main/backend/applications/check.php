<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);
$job_id = $_GET['job_id'] ?? '';

if (empty($job_id) || !is_numeric($job_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid job ID']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if user has applied for this job
    $query = "SELECT id FROM applications WHERE job_id = :job_id AND user_id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':job_id', $job_id);
    $stmt->bindParam(':user_id', $user['id']);
    $stmt->execute();

    echo json_encode([
        'success' => true,
        'has_applied' => $stmt->rowCount() > 0
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>