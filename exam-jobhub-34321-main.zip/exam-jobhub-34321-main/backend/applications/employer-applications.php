<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] !== 'employer') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only employers can view applications']);
        exit();
    }

    // Get applications for employer's jobs
    $query = "SELECT a.id, a.cover_letter, a.status, a.applied_at,
                     j.id as job_id, j.title as job_title, j.company,
                     u.name as applicant_name, u.email as applicant_email
              FROM applications a
              JOIN jobs j ON a.job_id = j.id
              JOIN users u ON a.user_id = u.id
              WHERE j.employer_id = :employer_id
              ORDER BY a.applied_at DESC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':employer_id', $user['id']);
    $stmt->execute();

    $applications = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $applications[] = [
            'id' => (int)$row['id'],
            'job_id' => (int)$row['job_id'],
            'job_title' => $row['job_title'],
            'company' => $row['company'],
            'applicant_name' => $row['applicant_name'],
            'applicant_email' => $row['applicant_email'],
            'cover_letter' => $row['cover_letter'],
            'status' => $row['status'],
            'applied_at' => $row['applied_at']
        ];
    }

    echo json_encode([
        'success' => true,
        'applications' => $applications
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
