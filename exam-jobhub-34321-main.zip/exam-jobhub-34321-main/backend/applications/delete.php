<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);

// Get application ID from request
$input = json_decode(file_get_contents('php://input'), true);
$application_id = $input['application_id'] ?? null;

if (!$application_id || !is_numeric($application_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Valid application ID required']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if application belongs to the user
    $query = "SELECT id FROM applications WHERE id = :application_id AND user_id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':application_id', $application_id);
    $stmt->bindParam(':user_id', $user['id']);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Application not found or unauthorized']);
        exit();
    }

    // Delete the application
    $query = "DELETE FROM applications WHERE id = :application_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':application_id', $application_id);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Application deleted successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to delete application']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
