<?php
require_once '../config/cors.php';
require_once '../config/database.php';

// Get Authorization header
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (empty($auth_header) || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

$token = substr($auth_header, 7);

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit();
}

$job_id = $input['job_id'] ?? '';
$cover_letter = $input['cover_letter'] ?? '';

// Validation
if (empty($job_id) || empty($cover_letter)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Job ID and cover letter are required']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify token and get user
    $query = "SELECT u.id, u.role 
              FROM users u 
              JOIN sessions s ON u.id = s.user_id 
              WHERE s.token = :token AND s.expires_at > NOW()";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] !== 'seeker') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only job seekers can apply for jobs']);
        exit();
    }

    // Check if job exists
    $query = "SELECT id FROM jobs WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $job_id);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Job not found']);
        exit();
    }

    // Check if user already applied
    $query = "SELECT id FROM applications WHERE job_id = :job_id AND user_id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':job_id', $job_id);
    $stmt->bindParam(':user_id', $user['id']);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'You have already applied for this job']);
        exit();
    }

    // Insert application
    $query = "INSERT INTO applications (job_id, user_id, cover_letter, status, applied_at) 
              VALUES (:job_id, :user_id, :cover_letter, 'pending', NOW())";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':job_id', $job_id);
    $stmt->bindParam(':user_id', $user['id']);
    $stmt->bindParam(':cover_letter', $cover_letter);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Application submitted successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to submit application']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>