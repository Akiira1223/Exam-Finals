-- Job Board Database Schema
-- Execute this in your phpMyAdmin or MySQL client

CREATE DATABASE IF NOT EXISTS job_board;
USE job_board;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('seeker', 'employer') NOT NULL DEFAULT 'seeker',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sessions table
CREATE TABLE sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Jobs table
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    company VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    type ENUM('full-time', 'part-time', 'contract', 'remote') NOT NULL,
    description TEXT NOT NULL,
    salary VARCHAR(100) DEFAULT '0',
    employer_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Applications table
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    user_id INT NOT NULL,
    cover_letter TEXT NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_application (job_id, user_id)
);

-- Insert sample data
INSERT INTO users (name, email, password, role) VALUES 
('John Employer', 'employer@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employer'),
('Jane Seeker', 'seeker@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seeker');

INSERT INTO jobs (title, company, location, type, description, salary, employer_id) VALUES
('Senior Software Developer', 'TechCorp Inc', 'San Francisco, CA', 'full-time', 'We are looking for an experienced software developer to join our team. Requirements include 5+ years of experience with React, Node.js, and PostgreSQL. You will be responsible for building scalable web applications and mentoring junior developers.', '120000', 1),
('Frontend Developer', 'StartupXYZ', 'New York, NY', 'full-time', 'Join our fast-growing startup as a Frontend Developer. We need someone passionate about creating beautiful, responsive user interfaces using React, TypeScript, and modern CSS. Experience with design systems is a plus.', '85000', 1),
('Product Manager', 'InnovateCo', 'Austin, TX', 'full-time', 'We are seeking a Product Manager to drive our product strategy and roadmap. You will work closely with engineering, design, and marketing teams to deliver exceptional user experiences. MBA preferred but not required.', '110000', 1),
('Data Analyst', 'DataDriven LLC', 'Remote', 'remote', 'Remote Data Analyst position focusing on business intelligence and analytics. Proficiency in SQL, Python, and Tableau required. You will help drive data-driven decisions across the organization.', '75000', 1),
('UX Designer', 'DesignStudio', 'Los Angeles, CA', 'contract', '6-month contract position for an experienced UX Designer. Work on exciting projects for various clients. Portfolio showcasing mobile and web design required. Figma and Adobe Creative Suite experience essential.', '65000', 1);