# Complete VS Code Transfer Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Step-by-Step Transfer Process](#step-by-step-transfer-process)
3. [Backend Setup (PHP & MySQL)](#backend-setup-php--mysql)
4. [Complete Project Review](#complete-project-review)
5. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software

#### 1. Node.js and npm
- **What it is**: JavaScript runtime environment needed to run the React application
- **Download**: https://nodejs.org/
- **Recommended version**: LTS (Long Term Support) - currently v20.x or v18.x
- **How to verify installation**:
  ```bash
  node --version
  npm --version
  ```
- **Expected output**: Should show version numbers (e.g., v20.11.0 and 10.2.4)

#### 2. Git
- **What it is**: Version control system to clone the repository
- **Download**: https://git-scm.com/downloads
- **How to verify installation**:
  ```bash
  git --version
  ```
- **Expected output**: git version 2.x.x

#### 3. Visual Studio Code
- **What it is**: Code editor/IDE
- **Download**: https://code.visualstudio.com/
- **Version**: Latest stable version

#### 4. PHP (for backend)
- **What it is**: Server-side scripting language for the backend API
- **Download**: https://www.php.net/downloads.php
- **Recommended version**: PHP 7.4 or higher (8.x preferred)
- **How to verify installation**:
  ```bash
  php --version
  ```
- **Expected output**: PHP 7.4.x or 8.x.x

#### 5. MySQL
- **What it is**: Database management system
- **Options**:
  - **XAMPP** (Windows/Mac/Linux): https://www.apachefriends.org/ - Includes PHP, MySQL, and Apache
  - **MAMP** (Mac): https://www.mamp.info/
  - **MySQL Community Server** (standalone): https://dev.mysql.com/downloads/mysql/
- **Recommended**: XAMPP for beginners (all-in-one solution)

#### 6. Composer (Optional but recommended)
- **What it is**: PHP dependency manager
- **Download**: https://getcomposer.org/download/
- **Usage**: Manage PHP packages if needed later

---

## Step-by-Step Transfer Process

### Phase 1: Connect Lovable to GitHub

#### Step 1.1: Open GitHub Integration in Lovable
1. Log into your Lovable project: https://lovable.dev/projects/2c4b63ba-6539-487e-a8c4-ec0028530c9d
2. Look at the **top-right corner** of the screen
3. Find and click the **"GitHub"** button (it has the GitHub logo)
4. A dropdown menu will appear

#### Step 1.2: Authorize GitHub Connection
1. Click **"Connect to GitHub"** from the dropdown
2. You'll be redirected to GitHub's authorization page
3. Click **"Authorize Lovable"** on GitHub
4. You may need to enter your GitHub password
5. Select which GitHub account/organization to use (if you have multiple)

#### Step 1.3: Create Repository
1. Back in Lovable, click the **"GitHub"** button again
2. Click **"Create Repository"**
3. A dialog will appear asking for:
   - **Repository name**: Enter a descriptive name (e.g., `job-board-app`)
   - **Visibility**: Choose Public or Private
   - **Repository owner**: Confirm your GitHub username/org
4. Click **"Create"** button
5. Wait for confirmation message (usually takes 5-10 seconds)
6. You'll see "Repository created successfully" message

#### Step 1.4: Note Your Repository URL
1. After creation, click **"GitHub"** button again
2. Click **"View on GitHub"** - this opens your new repository
3. On GitHub, click the green **"Code"** button
4. Copy the HTTPS URL (looks like: `https://github.com/YOUR-USERNAME/job-board-app.git`)
5. Save this URL - you'll need it in the next phase

---

### Phase 2: Clone Repository to Local Machine

#### Step 2.1: Choose Installation Directory
1. Open **File Explorer** (Windows) or **Finder** (Mac)
2. Navigate to where you want to store the project
3. Recommended locations:
   - **Windows**: `C:\Users\YourName\Projects\` or `C:\Dev\`
   - **Mac/Linux**: `~/Projects/` or `~/Development/`
4. Create the folder if it doesn't exist

#### Step 2.2: Open Terminal/Command Prompt
1. **Windows**:
   - Press `Win + R`
   - Type `cmd` and press Enter
   - OR Right-click in your Projects folder and select "Git Bash Here" (if Git Bash is installed)
2. **Mac**:
   - Press `Cmd + Space`
   - Type "Terminal" and press Enter
3. **Linux**:
   - Press `Ctrl + Alt + T`

#### Step 2.3: Navigate to Installation Directory
```bash
# Windows example
cd C:\Users\YourName\Projects

# Mac/Linux example
cd ~/Projects
```

#### Step 2.4: Clone the Repository
```bash
git clone https://github.com/YOUR-USERNAME/job-board-app.git
```
- Replace the URL with your actual repository URL from Step 1.4
- **What happens**: Git downloads all project files to your computer
- **Expected output**: You'll see progress messages showing files being downloaded
- **Duration**: Usually 10-30 seconds depending on project size

#### Step 2.5: Navigate into Project Folder
```bash
cd job-board-app
```
- Replace `job-board-app` with your actual repository name
- **Verify you're in the right place**:
  ```bash
  # Windows
  dir
  
  # Mac/Linux
  ls
  ```
- **Expected output**: You should see files like `package.json`, `vite.config.ts`, `src/`, `backend/`, etc.

---

### Phase 3: Install Dependencies

#### Step 3.1: Verify Node.js Installation
```bash
node --version
npm --version
```
- **If either command fails**: Go back to Prerequisites and install Node.js

#### Step 3.2: Install npm Packages
```bash
npm install
```
- **What it does**: Installs all JavaScript packages listed in `package.json`
- **Duration**: 1-3 minutes (downloads ~200-300 MB)
- **Expected output**: 
  ```
  added 1247 packages, and audited 1248 packages in 2m
  ```
- **Files created**: A `node_modules/` folder appears with all dependencies

#### Step 3.3: Verify Installation
```bash
# Check if node_modules folder exists
# Windows
dir node_modules

# Mac/Linux
ls node_modules
```
- **Expected**: You should see hundreds of folders (each is a package)

---

### Phase 4: Setup Backend (PHP & MySQL)

#### Step 4.1: Install and Start XAMPP

##### Windows:
1. Download XAMPP from https://www.apachefriends.org/
2. Run the installer (xampp-windows-x64-X.X.X-installer.exe)
3. Choose installation directory (default: C:\xampp)
4. Select components: Check **Apache** and **MySQL** (minimum required)
5. Complete installation
6. Launch **XAMPP Control Panel**
7. Click **"Start"** next to Apache
8. Click **"Start"** next to MySQL
9. **Verify**: Both should show green "Running" status

##### Mac:
1. Download XAMPP for Mac
2. Mount the DMG file
3. Drag XAMPP to Applications folder
4. Open XAMPP from Applications
5. Click **"Start"** for Apache Server
6. Click **"Start"** for MySQL Database
7. **Verify**: Status should show "running" in green

#### Step 4.2: Create Database

##### Option A: Using phpMyAdmin (Recommended)
1. Open browser and go to: http://localhost/phpmyadmin
2. Click **"New"** in the left sidebar
3. Enter database name: `job_board`
4. Select **"utf8mb4_general_ci"** from Collation dropdown
5. Click **"Create"** button
6. **Verify**: You should see `job_board` in the left sidebar

##### Option B: Using MySQL Command Line
1. Open terminal/command prompt
2. Navigate to MySQL:
   ```bash
   # Windows (XAMPP)
   cd C:\xampp\mysql\bin
   mysql -u root -p
   
   # Mac (XAMPP)
   cd /Applications/XAMPP/xamppfiles/bin
   ./mysql -u root -p
   ```
3. Press Enter when prompted for password (default is blank)
4. Create database:
   ```sql
   CREATE DATABASE job_board CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   ```
5. Verify:
   ```sql
   SHOW DATABASES;
   ```
6. Exit:
   ```sql
   EXIT;
   ```

#### Step 4.3: Import Database Schema
1. Locate the SQL file in your project:
   - **File location**: `backend/setup.sql`
2. **Option A - Using phpMyAdmin**:
   - Go to http://localhost/phpmyadmin
   - Click on `job_board` database in left sidebar
   - Click **"Import"** tab at the top
   - Click **"Choose File"** button
   - Navigate to your project folder
   - Select `backend/setup.sql`
   - Scroll down and click **"Go"** button
   - **Expected**: Success message with number of queries executed
3. **Option B - Using Command Line**:
   ```bash
   # Windows
   cd C:\xampp\mysql\bin
   mysql -u root -p job_board < "C:\Users\YourName\Projects\job-board-app\backend\setup.sql"
   
   # Mac
   cd /Applications/XAMPP/xamppfiles/bin
   ./mysql -u root -p job_board < ~/Projects/job-board-app/backend/setup.sql
   ```

#### Step 4.4: Verify Database Tables
1. In phpMyAdmin, click on `job_board` database
2. You should see three tables:
   - `users`
   - `jobs`
   - `applications`
3. Click on each table and click "Structure" tab to verify columns exist

#### Step 4.5: Configure Database Connection
1. Open VS Code (we'll do this in the next phase)
2. Navigate to: `backend/config/database.php`
3. Verify settings match your XAMPP configuration:
   ```php
   private $host = 'localhost';      // Should match
   private $db_name = 'job_board';   // Database we created
   private $username = 'root';        // Default XAMPP user
   private $password = '';            // Default XAMPP (blank)
   ```
4. **If you changed MySQL password**: Update `$password` value

#### Step 4.6: Configure Backend Path
1. Copy the `backend/` folder to XAMPP's web directory:
   
   **Windows**:
   ```bash
   # Copy entire backend folder
   xcopy /E /I "C:\Users\YourName\Projects\job-board-app\backend" "C:\xampp\htdocs\job-board-api"
   ```
   
   **Mac**:
   ```bash
   cp -R ~/Projects/job-board-app/backend /Applications/XAMPP/xamppfiles/htdocs/job-board-api
   ```

2. **Test backend is accessible**:
   - Open browser
   - Go to: http://localhost/job-board-api/auth/check.php
   - **Expected**: JSON response (even if error, it means PHP is working)

---

### Phase 5: Open Project in VS Code

#### Step 5.1: Launch VS Code
1. Open Visual Studio Code application
2. **Method 1 - From VS Code**:
   - Click **"File"** → **"Open Folder"**
   - Navigate to your project folder (e.g., `C:\Users\YourName\Projects\job-board-app`)
   - Click **"Select Folder"**
3. **Method 2 - From Terminal** (if still in project folder):
   ```bash
   code .
   ```
   - The `.` means "current directory"
   - VS Code will open with your project loaded

#### Step 5.2: Trust Workspace
1. VS Code may show a dialog: **"Do you trust the authors of the files in this folder?"**
2. Click **"Yes, I trust the authors"**
3. **Why**: This enables full VS Code features

#### Step 5.3: Explore Project Structure
1. Look at the **Explorer** panel on the left (folder icon)
2. You should see:
   ```
   job-board-app/
   ├── backend/
   ├── public/
   ├── src/
   ├── node_modules/
   ├── package.json
   ├── vite.config.ts
   └── ...other files
   ```

---

### Phase 6: Install VS Code Extensions

#### Step 6.1: Open Extensions Panel
1. Click the **Extensions** icon in left sidebar (looks like 4 squares)
2. OR press: `Ctrl + Shift + X` (Windows/Linux) or `Cmd + Shift + X` (Mac)

#### Step 6.2: Install Required Extensions

##### Extension 1: ESLint
1. Type **"ESLint"** in search box
2. Find "ESLint" by Microsoft (should be first result)
3. Click **"Install"** button
4. **What it does**: Detects JavaScript/TypeScript errors and code quality issues
5. **Indicator**: Green checkmark appears when installed

##### Extension 2: Prettier - Code Formatter
1. Type **"Prettier"** in search
2. Find "Prettier - Code formatter" by Prettier
3. Click **"Install"**
4. **What it does**: Automatically formats code to consistent style
5. **Configure**:
   - Click gear icon next to extension
   - Click **"Extension Settings"**
   - Check **"Format On Save"**

##### Extension 3: Tailwind CSS IntelliSense
1. Type **"Tailwind CSS IntelliSense"**
2. Find official extension by Tailwind Labs
3. Click **"Install"**
4. **What it does**: Autocomplete for Tailwind CSS classes, shows color previews
5. **Features**: 
   - Class name suggestions as you type
   - CSS preview on hover
   - Syntax highlighting

##### Extension 4: ES7+ React/Redux/React-Native snippets
1. Type **"ES7 React"** in search
2. Find "ES7+ React/Redux/React-Native snippets" by dsznajder
3. Click **"Install"**
4. **What it does**: Code snippets for React components
5. **Usage examples**:
   - Type `rafce` → Creates functional component with export
   - Type `useState` → Imports and creates useState hook

##### Extension 5: PHP Intelephense (for backend)
1. Type **"PHP Intelephense"**
2. Find "PHP Intelephense" by Ben Mewburn
3. Click **"Install"**
4. **What it does**: PHP language support, autocomplete, error detection

##### Extension 6: Path Intellisense (Optional but helpful)
1. Type **"Path Intellisense"**
2. Find "Path Intellisense" by Christian Kohler
3. Click **"Install"**
4. **What it does**: Autocompletes file paths in import statements

#### Step 6.3: Verify Extensions
1. Click **"Extensions"** icon again
2. Look at **"INSTALLED"** section
3. You should see all 6 extensions listed
4. Each should show **"Reload Required"** or already be active

#### Step 6.4: Configure VS Code Settings (Optional)
1. Press `Ctrl + ,` (Windows/Linux) or `Cmd + ,` (Mac) to open Settings
2. Recommended settings to add:
   ```json
   {
     "editor.formatOnSave": true,
     "editor.defaultFormatter": "esbenp.prettier-vscode",
     "editor.codeActionsOnSave": {
       "source.fixAll.eslint": true
     },
     "tailwindCSS.experimental.classRegex": [
       ["cva\\(([^)]*)\\)", "[\"'`]([^\"'`]*).*?[\"'`]"]
     ]
   }
   ```
3. **To add these**:
   - Click gear icon (bottom left) → **"Settings"**
   - Click **"Open Settings (JSON)"** icon in top right
   - Add settings to the JSON object

---

### Phase 7: Start Development Server

#### Step 7.1: Open Integrated Terminal
1. In VS Code, click **"Terminal"** in top menu
2. Click **"New Terminal"**
3. OR press: `Ctrl + ` ` (backtick) on Windows/Linux, `Cmd + ` ` on Mac
4. **Result**: Terminal panel opens at bottom of VS Code

#### Step 7.2: Verify You're in Project Root
```bash
# Windows
cd

# Mac/Linux
pwd
```
- **Expected**: Should show your project directory path
- **If not in project root**:
  ```bash
  # Navigate to project
  cd path/to/job-board-app
  ```

#### Step 7.3: Start Vite Development Server
```bash
npm run dev
```
- **What happens**: 
  - Vite starts development server
  - Compiles React application
  - Watches for file changes
- **Expected output**:
  ```
  VITE v5.x.x  ready in 500 ms
  
  ➜  Local:   http://localhost:8080/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
  ```
- **Duration**: Initial startup takes 5-10 seconds

#### Step 7.4: Open Application in Browser
1. **Method 1**: Click the URL in terminal (Ctrl+Click or Cmd+Click)
2. **Method 2**: Open browser manually and go to: http://localhost:8080
3. **Expected**: Your job board application should load
4. **If you see errors**: Check console (F12) for error messages

#### Step 7.5: Verify Hot Reload Works
1. Keep browser and VS Code visible side-by-side
2. In VS Code, open: `src/App.tsx`
3. Make a small change (e.g., change some text)
4. Save file: `Ctrl + S` (Windows/Linux) or `Cmd + S` (Mac)
5. **Expected**: Browser automatically refreshes with your changes (within 1 second)

---

### Phase 8: Testing the Application

#### Step 8.1: Verify Backend Connection
1. Open browser console: Press `F12`
2. Click **"Network"** tab
3. In your application, try to perform an action that hits the backend (e.g., view jobs list)
4. **Check**: You should see API requests to `localhost/job-board-api/*`
5. **If 404 errors**: Check that backend was copied to XAMPP htdocs correctly

#### Step 8.2: Test Registration Flow
1. Navigate to registration page
2. Fill in test data:
   - Email: test@example.com
   - Password: Test123!
   - User type: job_seeker or employer
3. Submit form
4. **Expected**: Success message or redirect to login
5. **If error**: Check browser console and network tab for specific error

#### Step 8.3: Test Login Flow
1. Navigate to login page
2. Use credentials from registration
3. Submit
4. **Expected**: Redirect to dashboard or home
5. **Verify**: User info should be stored (check localStorage in dev tools)

#### Step 8.4: Verify Database Entries
1. Go to phpMyAdmin: http://localhost/phpmyadmin
2. Click `job_board` database
3. Click `users` table
4. Click **"Browse"**
5. **Expected**: You should see your test user entry with hashed password

---

## Complete Project Review

### Project Structure Overview

```
job-board-app/
│
├── backend/                    # PHP Backend API
│   ├── applications/           # Job application endpoints
│   ├── auth/                   # Authentication endpoints
│   ├── config/                 # Database configuration
│   ├── database/               # Database connection classes
│   ├── jobs/                   # Job management endpoints
│   ├── models/                 # Data models (OOP)
│   └── setup.sql               # Database schema
│
├── public/                     # Static assets
│   ├── favicon.ico             # Browser tab icon
│   ├── placeholder.svg         # Placeholder image
│   └── robots.txt              # SEO robots file
│
├── src/                        # React application source
│   ├── components/             # Reusable components
│   │   ├── ui/                 # UI component library (shadcn)
│   │   ├── Header.tsx          # Main header component
│   │   └── JobCard.tsx         # Job listing card
│   │
│   ├── contexts/               # React contexts
│   │   └── AuthContext.tsx    # Authentication state management
│   │
│   ├── hooks/                  # Custom React hooks
│   │   ├── useApplications.ts  # Application data management
│   │   ├── useAsync.ts         # Async operation handling
│   │   ├── useAuth.ts          # Authentication hooks
│   │   ├── useDebounce.ts      # Debouncing utility
│   │   ├── useJobs.ts          # Job data fetching
│   │   └── ...more hooks
│   │
│   ├── lib/                    # Utility libraries
│   │   └── utils.ts            # Helper functions
│   │
│   ├── pages/                  # Page components
│   │   ├── Dashboard.tsx       # User dashboard
│   │   ├── Home.tsx            # Landing page
│   │   ├── Index.tsx           # Main index page
│   │   ├── JobDetails.tsx      # Job detail view
│   │   ├── Login.tsx           # Login page
│   │   ├── NotFound.tsx        # 404 page
│   │   ├── PostJob.tsx         # Job posting form
│   │   └── Register.tsx        # Registration page
│   │
│   ├── App.css                 # Global styles
│   ├── App.tsx                 # Main app component
│   ├── index.css               # Tailwind + design system
│   ├── main.tsx                # Application entry point
│   └── vite-env.d.ts           # TypeScript definitions
│
├── .gitignore                  # Git ignore rules
├── .htaccess                   # Apache configuration
├── eslint.config.js            # ESLint configuration
├── index.html                  # HTML entry point
├── package.json                # npm dependencies
├── package-lock.json           # npm lock file
├── postcss.config.js           # PostCSS configuration
├── README.md                   # Project documentation
├── tailwind.config.ts          # Tailwind CSS configuration
├── tsconfig.json               # TypeScript configuration
└── vite.config.ts              # Vite bundler configuration
```

---

### Backend Components Detailed Review

#### `/backend/applications/`
**Purpose**: Handles all job application-related operations

##### `apply.php`
- **Location**: `backend/applications/apply.php`
- **Method**: POST
- **Purpose**: Submit a job application
- **Accepts**:
  - `job_id` (integer) - ID of job being applied to
  - `user_id` (integer) - ID of applicant
  - `cover_letter` (text) - Optional cover letter
- **Returns**: JSON with success status and application ID
- **Database**: Inserts into `applications` table
- **Validation**: 
  - Checks if job exists
  - Prevents duplicate applications
  - Validates user is authenticated

##### `check.php`
- **Location**: `backend/applications/check.php`
- **Method**: GET
- **Purpose**: Check if user has already applied to a job
- **Parameters**:
  - `job_id` (integer)
  - `user_id` (integer)
- **Returns**: `{ "has_applied": true/false }`
- **Use case**: Disable "Apply" button if already applied

##### `my-applications.php`
- **Location**: `backend/applications/my-applications.php`
- **Method**: GET
- **Purpose**: Retrieve all applications for logged-in user
- **Parameters**: `user_id` (from session/auth)
- **Returns**: Array of application objects with job details
- **Data included**:
  - Application ID, status, date
  - Job title, company, location
  - Employer information

---

#### `/backend/auth/`
**Purpose**: Authentication and user management

##### `check.php`
- **Location**: `backend/auth/check.php`
- **Method**: GET
- **Purpose**: Verify if user session is valid
- **Returns**: User object if authenticated, error if not
- **Usage**: Called on app initialization to restore session
- **Security**: Validates JWT token or session ID

##### `login.php`
- **Location**: `backend/auth/login.php`
- **Method**: POST
- **Purpose**: Authenticate user credentials
- **Accepts**:
  - `email` (string)
  - `password` (string)
- **Process**:
  1. Validates email format
  2. Queries database for user
  3. Verifies password hash using `password_verify()`
  4. Creates session or JWT token
- **Returns**: User object + auth token
- **Security**: 
  - Passwords stored as bcrypt hashes
  - Prevents timing attacks
  - Rate limiting (if implemented)

##### `register.php`
- **Location**: `backend/auth/register.php`
- **Method**: POST
- **Purpose**: Create new user account
- **Accepts**:
  - `email` (string) - Must be unique
  - `password` (string) - Min 8 characters
  - `full_name` (string)
  - `user_type` (enum) - 'job_seeker' or 'employer'
  - `company_name` (string) - If employer
- **Process**:
  1. Validates input data
  2. Checks email uniqueness
  3. Hashes password with `password_hash()`
  4. Inserts into `users` table
- **Returns**: User object + auth token
- **Security**: 
  - Password hashed with bcrypt (cost factor 10)
  - SQL injection prevention via prepared statements

---

#### `/backend/config/`
**Purpose**: Configuration files

##### `database.php`
- **Location**: `backend/config/database.php`
- **Purpose**: Legacy database connection class
- **Class**: `Database`
- **Properties**:
  - `$host`: Database host (default: localhost)
  - `$db_name`: Database name (default: job_board)
  - `$username`: DB user (default: root)
  - `$password`: DB password (default: empty)
- **Method**: `getConnection()` - Returns PDO instance
- **Note**: Being replaced by `DatabaseConnection.php`

##### `cors.php`
- **Location**: `backend/config/cors.php`
- **Purpose**: Cross-Origin Resource Sharing headers
- **Headers set**:
  - `Access-Control-Allow-Origin: *`
  - `Access-Control-Allow-Methods: GET, POST, PUT, DELETE`
  - `Access-Control-Allow-Headers: Content-Type, Authorization`
- **Usage**: Included at top of all API endpoints
- **Why needed**: Allows React app (localhost:8080) to call API (localhost/job-board-api)

---

#### `/backend/database/`
**Purpose**: Modern OOP database connection

##### `DatabaseConnection.php`
- **Location**: `backend/database/DatabaseConnection.php`
- **Design Pattern**: Singleton
- **Purpose**: Single point of database connection management
- **Key Features**:
  - **Single Instance**: Only one DB connection per request
  - **Auto-reconnect**: Handles connection drops
  - **Transaction support**: Begin, commit, rollback methods
  - **Error handling**: Throws exceptions on failure
- **Configuration**:
  ```php
  private $host = 'localhost';
  private $dbName = 'job_board';
  private $username = 'root';
  private $password = '';
  ```
- **PDO Options**:
  - `ERRMODE_EXCEPTION`: Throws exceptions on errors
  - `FETCH_ASSOC`: Returns associative arrays
  - `EMULATE_PREPARES: false`: Uses real prepared statements
- **Usage**:
  ```php
  $db = DatabaseConnection::getInstance();
  $conn = $db->getConnection();
  ```

---

#### `/backend/jobs/`
**Purpose**: Job listing CRUD operations

##### `create.php`
- **Location**: `backend/jobs/create.php`
- **Method**: POST
- **Purpose**: Create new job posting (employers only)
- **Accepts**:
  - `title` (string, required) - Job title
  - `description` (text, required) - Full description
  - `company` (string, required) - Company name
  - `location` (string, required) - Job location
  - `salary_min` (integer, optional) - Minimum salary
  - `salary_max` (integer, optional) - Maximum salary
  - `job_type` (enum) - full-time, part-time, contract, freelance
  - `experience_level` (enum) - entry, mid, senior, lead
  - `skills` (array) - Required skills
  - `benefits` (array) - Job benefits
- **Returns**: Created job object with ID
- **Authorization**: Requires user_type = 'employer'
- **Validation**: All required fields must be present

##### `delete.php`
- **Location**: `backend/jobs/delete.php`
- **Method**: DELETE
- **Purpose**: Remove job posting
- **Parameters**: `job_id` (integer)
- **Authorization**: Only job owner can delete
- **Process**:
  1. Verifies job exists
  2. Checks user is job owner
  3. Soft deletes or permanently removes
- **Returns**: Success confirmation

##### `details.php`
- **Location**: `backend/jobs/details.php`
- **Method**: GET
- **Purpose**: Fetch single job with full details
- **Parameters**: `id` (integer) - Job ID
- **Returns**: Complete job object including:
  - All job fields
  - Employer information
  - Application count
  - Related jobs
- **Use case**: Job detail page view

##### `list-filtered.php`
- **Location**: `backend/jobs/list-filtered.php`
- **Method**: GET
- **Purpose**: Search and filter job listings
- **Parameters**:
  - `search` (string) - Search in title/description
  - `location` (string) - Filter by location
  - `job_type` (string) - Filter by type
  - `experience_level` (string) - Filter by experience
  - `salary_min` (integer) - Minimum salary filter
  - `company` (string) - Filter by company
  - `page` (integer) - Pagination page number
  - `limit` (integer) - Results per page
- **Returns**: 
  - Array of filtered jobs
  - Total count
  - Pagination metadata
- **Features**:
  - Full-text search
  - Multiple filters can be combined
  - Sorted by creation date (newest first)

##### `list.php`
- **Location**: `backend/jobs/list.php`
- **Method**: GET
- **Purpose**: Retrieve all active job listings
- **Parameters**:
  - `page` (integer) - Default 1
  - `limit` (integer) - Default 20
- **Returns**: Paginated array of jobs
- **Data per job**:
  - Basic job info (title, company, location)
  - Salary range
  - Posted date
  - Application count
- **Use case**: Home page job list

##### `statistics.php`
- **Location**: `backend/jobs/statistics.php`
- **Method**: GET
- **Purpose**: Analytics data for employers
- **Returns**:
  - Total jobs posted by user
  - Total applications received
  - Applications per job
  - Average applications per job
  - Recent application activity
- **Authorization**: Employers only
- **Use case**: Employer dashboard analytics

##### `update.php`
- **Location**: `backend/jobs/update.php`
- **Method**: PUT
- **Purpose**: Modify existing job posting
- **Accepts**: Same fields as `create.php` plus:
  - `job_id` (integer) - Required
  - `status` (enum) - open, closed, filled
- **Authorization**: Only job owner can update
- **Returns**: Updated job object
- **Validation**: Checks all required fields

---

#### `/backend/models/`
**Purpose**: Object-Oriented data models

##### `BaseModel.php`
- **Location**: `backend/models/BaseModel.php`
- **Purpose**: Abstract base class for all models
- **Provides**:
  - Database connection access
  - Common CRUD methods
  - Data validation methods
  - Error handling
- **Methods**:
  - `find($id)` - Find record by ID
  - `findAll()` - Get all records
  - `create($data)` - Insert new record
  - `update($id, $data)` - Update record
  - `delete($id)` - Delete record
  - `validate($data, $rules)` - Validation logic
- **Benefits**: Reduces code duplication across models

##### `JobModel.php`
- **Location**: `backend/models/JobModel.php`
- **Purpose**: Job-specific business logic
- **Extends**: BaseModel
- **Properties**:
  - `$table = 'jobs'`
  - `$fillable` - Array of allowed fields
- **Custom Methods**:
  - `findByEmployer($employer_id)` - Get jobs by employer
  - `search($criteria)` - Advanced search
  - `getFeatured()` - Get featured jobs
  - `incrementViews($job_id)` - Track view count
  - `getRelated($job_id)` - Similar jobs algorithm
- **Validation Rules**:
  - Title: Required, max 255 chars
  - Description: Required, min 100 chars
  - Salary: Positive integers, max > min
  - Location: Required

##### `ApplicationModel.php`
- **Location**: `backend/models/ApplicationModel.php`
- **Purpose**: Application-specific operations
- **Extends**: BaseModel
- **Properties**:
  - `$table = 'applications'`
- **Custom Methods**:
  - `findByUser($user_id)` - User's applications
  - `findByJob($job_id)` - Applications for a job
  - `checkDuplicate($user_id, $job_id)` - Prevent duplicates
  - `updateStatus($id, $status)` - Change application status
  - `getStatistics($user_id)` - Application stats
- **Status Values**: pending, reviewed, interview, accepted, rejected

---

#### `/backend/setup.sql`
- **Location**: `backend/setup.sql`
- **Purpose**: Database schema initialization
- **Contents**: Creates 3 tables

##### Users Table
```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  user_type ENUM('job_seeker', 'employer') NOT NULL,
  company_name VARCHAR(255) NULL,
  phone VARCHAR(20) NULL,
  location VARCHAR(255) NULL,
  bio TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```
**Indexes**: 
- Primary key on `id`
- Unique index on `email`
- Index on `user_type` for filtering

##### Jobs Table
```sql
CREATE TABLE jobs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employer_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  company VARCHAR(255) NOT NULL,
  location VARCHAR(255) NOT NULL,
  salary_min INT NULL,
  salary_max INT NULL,
  job_type ENUM('full-time', 'part-time', 'contract', 'freelance') NOT NULL,
  experience_level ENUM('entry', 'mid', 'senior', 'lead') NOT NULL,
  skills JSON NULL,
  benefits JSON NULL,
  status ENUM('open', 'closed', 'filled') DEFAULT 'open',
  views INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE
);
```
**Indexes**:
- Primary key on `id`
- Foreign key on `employer_id`
- Index on `status` for filtering
- Full-text index on `title, description` for search

##### Applications Table
```sql
CREATE TABLE applications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  job_id INT NOT NULL,
  user_id INT NOT NULL,
  cover_letter TEXT NULL,
  resume_url VARCHAR(500) NULL,
  status ENUM('pending', 'reviewed', 'interview', 'accepted', 'rejected') DEFAULT 'pending',
  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_application (job_id, user_id)
);
```
**Indexes**:
- Primary key on `id`
- Foreign keys on `job_id` and `user_id`
- Composite unique index on `(job_id, user_id)` prevents duplicates
- Index on `status` for filtering

---

### Frontend Components Detailed Review

#### `/src/components/`

##### `Header.tsx`
- **Location**: `src/components/Header.tsx`
- **Purpose**: Main navigation header
- **Features**:
  - Logo and branding
  - Navigation links (Home, Jobs, Dashboard)
  - Authentication status display
  - Login/Register buttons (if not logged in)
  - User menu dropdown (if logged in)
  - Logout functionality
  - Mobile-responsive hamburger menu
- **Dependencies**:
  - `useAuth` hook for auth state
  - `useNavigate` for routing
  - Radix UI for dropdown menu
- **Styling**: Sticky header with glassmorphism effect
- **Props**: None (uses context)

##### `JobCard.tsx`
- **Location**: `src/components/JobCard.tsx`
- **Purpose**: Reusable job listing card component
- **Props**:
  - `job` (object) - Job data
  - `onApply` (function) - Apply button callback
  - `showActions` (boolean) - Show apply button
- **Displays**:
  - Job title
  - Company name with logo
  - Location
  - Salary range (if available)
  - Job type badge
  - Experience level badge
  - Posted date (relative, e.g., "2 days ago")
  - Application count
- **Features**:
  - Click to view full details
  - Quick apply button
  - Save job functionality
  - Share job button
- **Styling**: Card with hover effects, responsive grid layout
- **Animations**: Smooth transitions on hover

---

#### `/src/components/ui/` (shadcn Components)
**Purpose**: Reusable UI component library built on Radix UI primitives

All components in this folder follow these patterns:
- Built with Radix UI primitives
- Styled with Tailwind CSS using design tokens
- Fully accessible (ARIA compliant)
- Support dark mode
- TypeScript typed
- Forwarded refs for composition

##### Key Components:

**`button.tsx`**
- Variants: default, destructive, outline, secondary, ghost, link
- Sizes: default, sm, lg, icon
- Usage: `<Button variant="outline" size="lg">Click me</Button>`

**`card.tsx`**
- Sub-components: Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter
- Usage: Container for content sections

**`input.tsx`**
- Styled text input
- Supports all native input attributes
- Integrated with react-hook-form

**`dialog.tsx`**
- Modal dialog overlay
- Sub-components: Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription
- Keyboard accessible (Esc to close)

**`dropdown-menu.tsx`**
- Context menu with sub-menus
- Supports checkboxes and radio groups
- Keyboard navigation

**`select.tsx`**
- Custom dropdown select
- Searchable options
- Grouped options support

**`toast.tsx`**
- Notification system
- Variants: default, destructive
- Auto-dismiss with timer
- Stacks multiple toasts

**`form.tsx`**
- Form wrapper integrating react-hook-form
- Components: Form, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage
- Automatic validation error display

**`tabs.tsx`**
- Tabbed interface
- Keyboard navigation
- Controlled or uncontrolled

**`table.tsx`**
- Responsive data table
- Sub-components: Table, TableHeader, TableBody, TableRow, TableCell
- Sortable columns support

**`pagination.tsx`**
- Page navigation component
- Previous/Next buttons
- Page number buttons
- Ellipsis for skipped pages

**`badge.tsx`**
- Status indicator badges
- Variants: default, secondary, destructive, outline
- Used for job types, status tags

**`separator.tsx`**
- Horizontal or vertical divider line
- Semantic spacing

**`progress.tsx`**
- Progress bar indicator
- Animated value changes

**`skeleton.tsx`**
- Loading placeholder
- Animated pulse effect
- Used during data fetching

---

#### `/src/contexts/`

##### `AuthContext.tsx`
- **Location**: `src/contexts/AuthContext.tsx`
- **Purpose**: Global authentication state management
- **Pattern**: React Context API
- **Provides**:
  ```typescript
  {
    user: User | null,
    isAuthenticated: boolean,
    isLoading: boolean,
    login: (email, password) => Promise<void>,
    logout: () => void,
    register: (userData) => Promise<void>,
    updateProfile: (data) => Promise<void>
  }
  ```
- **Features**:
  - Persists auth state to localStorage
  - Automatic session restoration on page load
  - Token refresh logic
  - Global loading state during auth operations
- **Usage**:
  ```typescript
  const { user, login, logout } = useAuth();
  ```
- **Storage**: Auth token in localStorage key: `auth_token`

---

#### `/src/hooks/` (Custom React Hooks)

##### `useJobs.ts`
- **Location**: `src/hooks/useJobs.ts`
- **Purpose**: Fetch and manage job listings
- **Returns**:
  ```typescript
  {
    jobs: Job[],
    isLoading: boolean,
    error: Error | null,
    refetch: () => void,
    hasMore: boolean,
    loadMore: () => void
  }
  ```
- **Features**:
  - Infinite scroll support
  - Automatic caching
  - Refetch on window focus
  - Error handling
- **Dependencies**: Uses `useAsync` hook

##### `useApplications.ts`
- **Location**: `src/hooks/useApplications.ts`
- **Purpose**: Manage job applications
- **Methods**:
  - `apply(jobId, coverLetter)` - Submit application
  - `checkStatus(jobId)` - Check if already applied
  - `getUserApplications()` - Get user's applications
  - `updateApplication(id, data)` - Update application
- **Returns**: Loading states and error handling
- **Features**: Optimistic updates, cache invalidation

##### `useJobFilters.ts`
- **Location**: `src/hooks/useJobFilters.ts`
- **Purpose**: Job search and filtering logic
- **State**:
  ```typescript
  {
    search: string,
    location: string,
    jobType: string[],
    experienceLevel: string[],
    salaryMin: number,
    company: string
  }
  ```
- **Methods**:
  - `setFilter(key, value)` - Update single filter
  - `clearFilters()` - Reset all filters
  - `applyFilters(jobs)` - Filter job array
- **Features**: 
  - URL query params sync
  - Debounced search input
  - Multi-select filters

##### `useJobSort.ts`
- **Location**: `src/hooks/useJobSort.ts`
- **Purpose**: Sort job listings
- **Sort Options**:
  - Newest first (default)
  - Oldest first
  - Salary (high to low)
  - Salary (low to high)
  - Alphabetical (A-Z)
  - Most applications
- **Returns**: `{ sortedJobs, sortBy, setSortBy }`
- **Usage**: `const { sortedJobs } = useJobSort(jobs, 'salary-desc')`

##### `usePagination.ts`
- **Location**: `src/hooks/usePagination.ts`
- **Purpose**: Pagination logic
- **Parameters**:
  - `items` - Array of items to paginate
  - `itemsPerPage` - Number of items per page
- **Returns**:
  ```typescript
  {
    currentPage: number,
    totalPages: number,
    paginatedItems: any[],
    goToPage: (page: number) => void,
    nextPage: () => void,
    prevPage: () => void,
    canGoNext: boolean,
    canGoPrev: boolean
  }
  ```
- **Features**: 
  - Auto-scroll to top on page change
  - URL sync
  - Boundary checks

##### `useDebounce.ts`
- **Location**: `src/hooks/useDebounce.ts`
- **Purpose**: Debounce value changes
- **Usage**: `const debouncedSearch = useDebounce(searchTerm, 500)`
- **Parameters**:
  - `value` - Value to debounce
  - `delay` - Delay in milliseconds (default 500)
- **Use case**: Prevent API calls on every keystroke in search

##### `useLocalStorage.ts`
- **Location**: `src/hooks/useLocalStorage.ts`
- **Purpose**: Persist state to localStorage
- **Usage**: `const [theme, setTheme] = useLocalStorage('theme', 'light')`
- **Features**:
  - Automatic JSON serialization
  - SSR safe
  - Syncs across tabs
  - Type-safe with TypeScript

##### `useAsync.ts`
- **Location**: `src/hooks/useAsync.ts`
- **Purpose**: Manage async operations
- **Returns**:
  ```typescript
  {
    execute: () => Promise<T>,
    status: 'idle' | 'pending' | 'success' | 'error',
    value: T | null,
    error: Error | null,
    isLoading: boolean,
    isSuccess: boolean,
    isError: boolean
  }
  ```
- **Features**:
  - Prevents race conditions
  - Automatic cleanup
  - Request cancellation

##### `useWindowSize.ts`
- **Location**: `src/hooks/useWindowSize.ts`
- **Purpose**: Track window dimensions
- **Returns**: `{ width: number, height: number }`
- **Features**: Debounced resize events, SSR safe
- **Use case**: Responsive behavior in JavaScript

##### `useClickOutside.ts`
- **Location**: `src/hooks/useClickOutside.ts`
- **Purpose**: Detect clicks outside element
- **Usage**: 
  ```typescript
  const ref = useRef();
  useClickOutside(ref, () => setIsOpen(false));
  ```
- **Use case**: Close dropdowns/modals on outside click

##### `useKeyPress.ts`
- **Location**: `src/hooks/useKeyPress.ts`
- **Purpose**: Detect keyboard shortcuts
- **Usage**: `const escPressed = useKeyPress('Escape')`
- **Supports**: Single keys, combinations (Ctrl+K), key codes

##### `useDocumentTitle.ts`
- **Location**: `src/hooks/useDocumentTitle.ts`
- **Purpose**: Update page title dynamically
- **Usage**: `useDocumentTitle('Job Details | Job Board')`
- **Features**: Restores original title on unmount

##### `useFormValidation.ts`
- **Location**: `src/hooks/useFormValidation.ts`
- **Purpose**: Form validation logic
- **Features**:
  - Real-time validation
  - Custom validation rules
  - Error message handling
  - Submit prevention if invalid
- **Integration**: Works with react-hook-form

---

#### `/src/pages/` (Page Components)

##### `Index.tsx`
- **Location**: `src/pages/Index.tsx`
- **Route**: `/`
- **Purpose**: Main landing/home page
- **Sections**:
  - Hero section with search bar
  - Featured jobs carousel
  - Job statistics (total jobs, companies)
  - Category quick links
  - Recent job listings
  - Call-to-action for employers
- **SEO**:
  - Title: "Find Your Dream Job | Job Board"
  - Meta description included
  - H1 tag: "Discover Your Next Career Opportunity"
- **Dependencies**: useJobs, JobCard component

##### `Home.tsx`
- **Location**: `src/pages/Home.tsx`
- **Route**: `/jobs`
- **Purpose**: Main job listing page with filters
- **Features**:
  - Search bar
  - Filter sidebar (location, type, experience, salary)
  - Sort dropdown
  - Job grid display
  - Pagination
  - Loading skeletons
  - Empty state if no results
- **State Management**:
  - useJobFilters for filtering
  - useJobSort for sorting
  - usePagination for page navigation
- **Responsive**: Filters collapse to drawer on mobile

##### `JobDetails.tsx`
- **Location**: `src/pages/JobDetails.tsx`
- **Route**: `/jobs/:id`
- **Purpose**: Full job posting details
- **Displays**:
  - Job title, company, location
  - Full description (markdown formatted)
  - Requirements and responsibilities
  - Salary range
  - Benefits list
  - Skills required
  - Application deadline
  - Employer information
  - Similar jobs section
- **Actions**:
  - Apply button (opens modal with cover letter form)
  - Save job
  - Share job (social media)
  - Report job
- **SEO**: Dynamic title and meta based on job data
- **Error Handling**: 404 if job not found

##### `Login.tsx`
- **Location**: `src/pages/Login.tsx`
- **Route**: `/login`
- **Purpose**: User authentication page
- **Form Fields**:
  - Email (required, validated)
  - Password (required, min 8 chars)
  - Remember me checkbox
- **Features**:
  - Form validation with react-hook-form
  - Error message display
  - "Forgot password?" link
  - "Sign up" link
  - Social login buttons (Google, LinkedIn)
- **Redirect**: After login, redirects to intended page or dashboard
- **Security**: Password hidden by default, toggle visibility button

##### `Register.tsx`
- **Location**: `src/pages/Register.tsx`
- **Route**: `/register`
- **Purpose**: New user registration
- **Form Fields**:
  - Full name (required)
  - Email (required, unique validation)
  - Password (required, strength indicator)
  - Confirm password (must match)
  - User type selection (Job Seeker / Employer)
  - Company name (if employer, required)
  - Terms & conditions acceptance
- **Validation**:
  - Email format check
  - Password strength requirements
  - Real-time field validation
  - Server-side uniqueness check
- **Features**:
  - Multi-step form (on mobile)
  - Progress indicator
  - Auto-login after successful registration
- **Error Handling**: Displays server errors inline

##### `Dashboard.tsx`
- **Location**: `src/pages/Dashboard.tsx`
- **Route**: `/dashboard`
- **Purpose**: User-specific dashboard
- **Access**: Protected route (requires authentication)
- **For Job Seekers**:
  - Applied jobs list with status
  - Saved jobs
  - Profile completion progress
  - Application statistics (charts)
  - Recommended jobs based on profile
  - Resume upload section
- **For Employers**:
  - Posted jobs list
  - Applications received (by job)
  - Quick stats (total jobs, total applications, views)
  - Analytics charts (applications over time)
  - Quick post job button
- **Features**:
  - Tab navigation between sections
  - Data tables with sorting
  - Action buttons (withdraw, edit, delete)
  - Real-time updates via polling

##### `PostJob.tsx`
- **Location**: `src/pages/PostJob.tsx`
- **Route**: `/post-job`
- **Purpose**: Employer job posting form
- **Access**: Employers only
- **Form Sections**:
  1. Basic Info (title, company, location)
  2. Job Details (type, experience, salary)
  3. Description (rich text editor)
  4. Requirements (skills, qualifications)
  5. Benefits and perks
  6. Application settings (deadline, questions)
- **Features**:
  - Multi-step wizard
  - Progress saving (draft mode)
  - Rich text editor with formatting
  - Skill tags input with autocomplete
  - Salary range slider
  - Preview before publish
- **Validation**: All required fields validated before submission
- **Success**: Redirects to job preview after creation

##### `NotFound.tsx`
- **Location**: `src/pages/NotFound.tsx`
- **Route**: `*` (catch-all)
- **Purpose**: 404 error page
- **Content**:
  - 404 illustration
  - "Page Not Found" message
  - Helpful links (Home, Jobs, Contact)
  - Search bar
- **SEO**: Proper 404 status code

---

### Configuration Files

##### `package.json`
- **Location**: Root directory
- **Purpose**: npm project manifest
- **Key Scripts**:
  - `dev`: Starts Vite dev server (port 8080)
  - `build`: Production build
  - `preview`: Preview production build
  - `lint`: Run ESLint
- **Dependencies**: Listed in "dependencies" section
- **Dev Dependencies**: Build tools (Vite, TypeScript, etc.)

##### `vite.config.ts`
- **Location**: Root directory
- **Purpose**: Vite bundler configuration
- **Settings**:
  - Server port: 8080
  - Server host: "::" (IPv6 all interfaces)
  - Path alias: `@` → `./src`
  - Plugins: React SWC, Lovable component tagger
- **Development**: Hot module replacement enabled
- **Build**: Optimized production output

##### `tailwind.config.ts`
- **Location**: Root directory
- **Purpose**: Tailwind CSS configuration
- **Content**: Scans `src/**/*.{ts,tsx}` for classes
- **Theme Extensions**:
  - Custom colors (from CSS variables)
  - Custom shadows
  - Custom gradients
  - Border radius values
  - Animations
- **Dark Mode**: Class-based (`class` strategy)
- **Plugins**: tailwindcss-animate

##### `tsconfig.json`
- **Location**: Root directory
- **Purpose**: TypeScript compiler configuration
- **Settings**:
  - Target: ES2020
  - Module: ESNext
  - JSX: react-jsx
  - Strict mode: enabled
  - Path aliases: `@/*` → `./src/*`
- **Include**: All `.ts` and `.tsx` files in `src/`
- **Exclude**: `node_modules/`

##### `eslint.config.js`
- **Location**: Root directory
- **Purpose**: ESLint rules configuration
- **Rules**:
  - No unused variables (warning)
  - No console.log in production (warning)
  - React hooks rules
  - Import order rules
- **Extends**: 
  - eslint:recommended
  - plugin:react/recommended
  - plugin:@typescript-eslint/recommended

##### `index.html`
- **Location**: Root directory
- **Purpose**: HTML entry point
- **Content**:
  - Meta tags (viewport, charset)
  - Title: Job Board
  - Links to favicon
  - Root div: `<div id="root"></div>`
  - Script tag: `<script type="module" src="/src/main.tsx"></script>`
- **Note**: Vite injects CSS and JS bundles during build

##### `postcss.config.js`
- **Location**: Root directory
- **Purpose**: PostCSS configuration
- **Plugins**:
  - tailwindcss: Processes Tailwind directives
  - autoprefixer: Adds vendor prefixes for browser compatibility

##### `.htaccess`
- **Location**: Root directory
- **Purpose**: Apache server configuration
- **Rules**:
  - Redirect all routes to index.html (SPA routing)
  - Enable gzip compression
  - Cache static assets
  - Security headers
- **Usage**: Only needed if deploying to Apache server

##### `.gitignore`
- **Location**: Root directory
- **Purpose**: Files excluded from Git
- **Ignored**:
  - node_modules/
  - dist/
  - .env files
  - OS files (.DS_Store)
  - IDE files (.vscode, .idea)

---

### Design System Files

##### `src/index.css`
- **Location**: `src/index.css`
- **Purpose**: Global styles and design tokens
- **Structure**:
  1. **Tailwind Directives**:
     ```css
     @tailwind base;
     @tailwind components;
     @tailwind utilities;
     ```
  2. **CSS Variables** (Design Tokens):
     - Colors (HSL format)
     - Shadows
     - Gradients
     - Spacing
     - Border radius
     - Transitions
  3. **Root Variables** (`:root`):
     - Light mode colors
  4. **Dark Mode** (`.dark`):
     - Dark mode color overrides
  5. **Custom Utilities**:
     - Glassmorphism effects
     - Gradient text
     - Custom animations

**Example Design Tokens**:
```css
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --primary: 221.2 83.2% 53.3%;
  --primary-light: 221.2 83.2% 63.3%;
  --primary-dark: 221.2 83.2% 43.3%;
  
  --gradient-hero: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary-dark)) 100%);
  
  --shadow-card: 0 4px 6px -1px rgb(0 0 0 / 0.1);
}
```

##### `src/App.css`
- **Location**: `src/App.css`
- **Purpose**: App-specific styles
- **Contains**:
  - Layout styles
  - Component-specific overrides
  - Animation keyframes
  - Responsive breakpoint styles
- **Usage**: Imported in `App.tsx`

##### `src/lib/utils.ts`
- **Location**: `src/lib/utils.ts`
- **Purpose**: Utility functions
- **Functions**:
  - `cn()` - Class name merger (clsx + tailwind-merge)
  - `formatDate()` - Date formatting helpers
  - `formatCurrency()` - Currency formatting
  - `truncate()` - String truncation with ellipsis
  - `slugify()` - URL-friendly string conversion
  - `debounce()` - Function debouncing
  - `throttle()` - Function throttling
- **Usage**: Imported throughout the app

---

### Application Entry Points

##### `src/main.tsx`
- **Location**: `src/main.tsx`
- **Purpose**: React application entry point
- **Responsibilities**:
  1. Imports global styles (`index.css`)
  2. Creates root React element
  3. Renders App component
  4. Wraps app in providers:
     - `BrowserRouter` (React Router)
     - `QueryClientProvider` (TanStack Query)
     - `AuthProvider` (Auth context)
     - `ThemeProvider` (Dark mode)
  5. Enables React Strict Mode (dev only)
- **Code Structure**:
  ```tsx
  import React from 'react'
  import ReactDOM from 'react-dom/client'
  import App from './App.tsx'
  import './index.css'
  
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AuthProvider>
            <ThemeProvider>
              <App />
            </ThemeProvider>
          </AuthProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </React.StrictMode>
  )
  ```

##### `src/App.tsx`
- **Location**: `src/App.tsx`
- **Purpose**: Root application component
- **Responsibilities**:
  1. Sets up routing structure
  2. Defines all routes and their components
  3. Implements protected routes
  4. Renders Header component
  5. Includes Toaster for notifications
- **Route Structure**:
  ```tsx
  <Routes>
    <Route path="/" element={<Index />} />
    <Route path="/jobs" element={<Home />} />
    <Route path="/jobs/:id" element={<JobDetails />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
    <Route path="/post-job" element={<ProtectedRoute><PostJob /></ProtectedRoute>} />
    <Route path="*" element={<NotFound />} />
  </Routes>
  ```

---

### Key Technologies Summary

#### Frontend Stack
1. **React 18.3.1**
   - Component-based UI
   - Hooks for state management
   - Context API for global state
   - Concurrent features

2. **TypeScript**
   - Type safety
   - Better IDE support
   - Fewer runtime errors
   - Self-documenting code

3. **Vite**
   - Lightning-fast HMR
   - Optimized builds
   - ES modules
   - Built-in dev server

4. **Tailwind CSS**
   - Utility-first styling
   - Design system via CSS variables
   - Responsive design
   - Dark mode support
   - JIT compiler for small bundle size

5. **React Router v6**
   - Client-side routing
   - Protected routes
   - URL params and query strings
   - Nested routes

6. **TanStack Query (React Query)**
   - Data fetching and caching
   - Automatic refetching
   - Optimistic updates
   - Background sync

7. **React Hook Form**
   - Performant form handling
   - Built-in validation
   - Minimal re-renders
   - Easy integration with UI libraries

8. **Zod**
   - Schema validation
   - Type inference
   - Runtime type checking
   - Works with React Hook Form

9. **Radix UI**
   - Accessible primitives
   - Unstyled components
   - Keyboard navigation
   - Focus management

10. **shadcn/ui**
    - Pre-built components using Radix
    - Copy-paste component library
    - Customizable with Tailwind
    - Type-safe

11. **Lucide React**
    - Icon library
    - Tree-shakeable
    - Consistent design
    - 1000+ icons

12. **Sonner**
    - Toast notifications
    - Beautiful animations
    - Stacking toasts
    - Promise-based API

13. **date-fns**
    - Date manipulation
    - Formatting
    - Locale support
    - Lightweight

#### Backend Stack
1. **PHP 7.4+**
   - Server-side logic
   - RESTful API
   - Session management
   - File uploads

2. **MySQL**
   - Relational database
   - ACID compliance
   - Foreign key constraints
   - Full-text search

3. **PDO**
   - Database abstraction
   - Prepared statements
   - SQL injection prevention
   - Multiple database support

4. **Apache/XAMPP**
   - Web server
   - PHP processor
   - MySQL server
   - Local development environment

---

## Troubleshooting

### Common Issues and Solutions

#### 0. **Backend API Returns 404** ⚠️ **MOST COMMON ISSUE**

**Symptoms**: 
- Browser console shows:
  ```
  GET http://localhost/job-board-api/jobs/list.php net::ERR_FAILED 404 (Not Found)
  Access to fetch has been blocked by CORS policy
  ```
- Browser displays Apache error:
  ```
  Not Found
  The requested URL was not found on this server.
  Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12 Server at localhost Port 80
  ```

**Root Cause**: The backend folder is NOT in XAMPP's htdocs directory.

**Complete Solution**:

1. **Locate your XAMPP htdocs folder:**
   - **Windows**: `C:\xampp\htdocs\`
   - **Mac**: `/Applications/XAMPP/htdocs/`
   - **Linux**: `/opt/lampp/htdocs/`

2. **Copy the backend folder to htdocs:**
   
   **Option A - Command Line (Recommended):**
   ```bash
   # Navigate to your project root first
   cd path/to/your/project
   
   # Windows (Command Prompt):
   xcopy backend C:\xampp\htdocs\job-board-api\ /E /I /Y
   
   # Windows (PowerShell):
   Copy-Item -Path backend -Destination C:\xampp\htdocs\job-board-api -Recurse -Force
   
   # Mac:
   cp -r backend /Applications/XAMPP/htdocs/job-board-api
   
   # Linux:
   sudo cp -r backend /opt/lampp/htdocs/job-board-api
   ```
   
   **Option B - Manual Copy:**
   - Open your project folder in File Explorer (Windows) or Finder (Mac)
   - Find the `backend` folder
   - Copy the entire `backend` folder
   - Navigate to `C:\xampp\htdocs\` (or your XAMPP htdocs location)
   - Paste it there
   - **Rename it from `backend` to `job-board-api`**

3. **Verify the correct structure:**
   
   Your `C:\xampp\htdocs\job-board-api\` should look like this:
   ```
   htdocs/
   └── job-board-api/          ← Must be named exactly this
       ├── config/
       │   ├── cors.php
       │   └── database.php
       ├── database/
       │   ├── DatabaseConnection.php
       │   └── setup.sql
       ├── models/
       │   ├── BaseModel.php
       │   ├── JobModel.php
       │   └── ApplicationModel.php
       ├── jobs/
       │   ├── list.php
       │   ├── list-filtered.php
       │   ├── create.php
       │   ├── update.php
       │   ├── delete.php
       │   ├── details.php
       │   └── statistics.php
       ├── auth/
       │   ├── login.php
       │   ├── register.php
       │   └── check.php
       └── applications/
           ├── apply.php
           ├── check.php
           └── my-applications.php
   ```

4. **Update the CORS configuration:**
   
   Edit `C:\xampp\htdocs\job-board-api\config\cors.php` to allow multiple dev server ports:
   
   The updated project already includes this fix, but if you copied an old version, replace the content with:
   ```php
   <?php
   // Enable CORS for localhost development
   $allowed_origins = [
       'http://localhost:8080',
       'http://localhost:8081',
       'http://localhost:5173',
       'http://localhost:3000'
   ];

   $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

   if (in_array($origin, $allowed_origins)) {
       header("Access-Control-Allow-Origin: $origin");
   }

   header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
   header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
   header("Access-Control-Allow-Credentials: true");

   // Handle preflight OPTIONS requests
   if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
       http_response_code(200);
       exit();
   }

   // Set content type to JSON
   header('Content-Type: application/json');
   ?>
   ```

5. **Test the backend directly:**
   - Open your browser
   - Navigate to: `http://localhost/job-board-api/jobs/list.php`
   - **Expected result**: JSON response like:
     ```json
     {"success":true,"jobs":[]}
     ```
   - **If you see 404**: The folder is not in the correct location, repeat steps 1-3
   - **If you see JSON**: Backend is working! Proceed to next step

6. **Restart Apache:**
   - Open XAMPP Control Panel
   - Click **Stop** next to Apache
   - Wait 2 seconds
   - Click **Start** next to Apache
   - Verify it shows green "Running" status

7. **Restart your dev server:**
   - In VS Code terminal, press `Ctrl+C` to stop the dev server
   - Run `npm run dev` again
   - Note the port it's running on (usually 8081 or 5173)

8. **Clear browser cache and test:**
   - Hard refresh: `Ctrl+Shift+R` (Windows/Linux) or `Cmd+Shift+R` (Mac)
   - Open DevTools (F12) → Network tab
   - Refresh the page
   - Look for the `list.php` request
   - Should show **200 OK** status with JSON response

**Why this happens:**
- XAMPP only serves PHP files from its `htdocs` directory
- Your project's `backend` folder is in your project directory (e.g., `Documents/my-project/backend/`)
- This folder is NOT accessible via `http://localhost/` because it's not inside `htdocs`
- You must physically copy/move the backend code into `htdocs` for Apache to serve it

**Important Notes:**
- When you make changes to backend PHP files, you need to copy them to htdocs again OR edit them directly in the htdocs folder
- For development, consider editing PHP files directly in `C:\xampp\htdocs\job-board-api\` to avoid copying repeatedly
- Remember to copy changes back to your project folder before committing to Git

---

#### 1. "npm install" fails

**Symptoms**: Error messages during `npm install`

**Solutions**:
- **Clear cache**:
  ```bash
  npm cache clean --force
  rm -rf node_modules package-lock.json
  npm install
  ```
- **Check Node version**: Ensure you're using Node 16+ (LTS)
  ```bash
  node --version
  # If wrong version, use nvm:
  nvm install 20
  nvm use 20
  ```
- **Network issues**: Try different registry
  ```bash
  npm config set registry https://registry.npmjs.org/
  ```

#### 2. "npm run dev" shows blank page

**Symptoms**: Browser shows white screen, no errors

**Solutions**:
- **Check console**: Open browser DevTools (F12), look for errors
- **Check terminal**: Look for compilation errors
- **Verify port**: Ensure port 8080 is not blocked
  ```bash
  # Windows
  netstat -ano | findstr :8080
  
  # Mac/Linux
  lsof -i :8080
  ```
- **Try different port**: Edit `vite.config.ts`:
  ```typescript
  server: {
    port: 3000, // Change this
  }
  ```

#### 3. Backend API returns 404

**Symptoms**: Network tab shows 404 for API calls

**Solutions**:
- **Verify backend location**:
  - Check `C:\xampp\htdocs\job-board-api\` (Windows)
  - Check `/Applications/XAMPP/xamppfiles/htdocs/job-board-api/` (Mac)
- **Test direct access**: Open http://localhost/job-board-api/auth/check.php
  - **Expected**: JSON response (even if error)
  - **If 404**: Backend files not in correct location
- **Check XAMPP**: Ensure Apache is running (green in control panel)
- **Restart Apache**: Stop and start in XAMPP control panel

#### 4. Database connection error

**Symptoms**: API returns "Connection error" message

**Solutions**:
- **Verify MySQL is running**: Check XAMPP control panel
- **Check credentials**: Open `backend/config/database.php`
  ```php
  // Verify these match your setup
  private $host = 'localhost';
  private $db_name = 'job_board';
  private $username = 'root';
  private $password = ''; // Usually blank for XAMPP
  ```
- **Test connection**:
  ```bash
  # Open MySQL command line from XAMPP
  mysql -u root -p
  # Press Enter (no password for default)
  SHOW DATABASES;
  # Should see 'job_board' listed
  ```
- **Recreate database**:
  ```sql
  DROP DATABASE IF EXISTS job_board;
  CREATE DATABASE job_board;
  USE job_board;
  SOURCE C:/Users/YourName/Projects/job-board-app/backend/setup.sql;
  ```

#### 5. CORS errors

**Symptoms**: Browser console shows "CORS policy" errors

**Solutions**:
- **Verify cors.php**: Check it's included in all backend files
  ```php
  // Should be at top of every API file
  require_once '../config/cors.php';
  ```
- **Check .htaccess**: Ensure CORS headers in `.htaccess`
  ```apache
  Header set Access-Control-Allow-Origin "*"
  Header set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
  ```
- **Restart Apache**: CORS headers require server restart

#### 6. "Module not found" errors

**Symptoms**: Import errors in terminal or browser

**Solutions**:
- **Reinstall dependencies**:
  ```bash
  rm -rf node_modules package-lock.json
  npm install
  ```
- **Check import paths**: Ensure using `@/` alias correctly
  ```typescript
  // ✅ Correct
  import { Button } from '@/components/ui/button'
  
  // ❌ Wrong
  import { Button } from '../../components/ui/button'
  ```
- **Restart dev server**: Stop (Ctrl+C) and run `npm run dev` again

#### 7. TypeScript errors

**Symptoms**: Red squiggly lines in VS Code, compilation errors

**Solutions**:
- **Install types**:
  ```bash
  npm install -D @types/node @types/react @types/react-dom
  ```
- **Restart TS server**: In VS Code
  - Press `Ctrl+Shift+P` (Cmd+Shift+P on Mac)
  - Type "TypeScript: Restart TS Server"
  - Press Enter
- **Check tsconfig.json**: Ensure paths are correct
- **Ignore build errors temporarily**: Add `// @ts-ignore` above error line

#### 8. Tailwind classes not working

**Symptoms**: Styles not applied, classes not recognized

**Solutions**:
- **Restart dev server**: Tailwind JIT needs restart after config changes
- **Check content paths**: In `tailwind.config.ts`:
  ```typescript
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // Ensure this matches your files
  ],
  ```
- **Verify imports**: Check `index.css` has Tailwind directives:
  ```css
  @tailwind base;
  @tailwind components;
  @tailwind utilities;
  ```
- **Install Tailwind extension**: Ensure "Tailwind CSS IntelliSense" is installed

#### 9. Git sync issues with Lovable

**Symptoms**: Changes not syncing between Lovable and local

**Solutions**:
- **Pull latest changes**:
  ```bash
  git pull origin main
  ```
- **Check branch**: Ensure you're on the correct branch
  ```bash
  git branch
  # Should show * main (or your working branch)
  ```
- **Force sync**: If conflicts exist
  ```bash
  git fetch origin
  git reset --hard origin/main
  ```
  **⚠️ Warning**: This discards local changes
- **Push local changes**:
  ```bash
  git add .
  git commit -m "Your message"
  git push origin main
  ```

#### 10. Slow performance in development

**Symptoms**: Hot reload takes long, app is sluggish

**Solutions**:
- **Close unused programs**: Free up RAM and CPU
- **Exclude from antivirus**: Add project folder to exclusions
- **Use production build**: For testing performance
  ```bash
  npm run build
  npm run preview
  ```
- **Clear browser cache**: Hard refresh (Ctrl+Shift+R)
- **Optimize imports**: Import only what you need
  ```typescript
  // ❌ Slow
  import * as Icons from 'lucide-react'
  
  // ✅ Fast
  import { Home, User } from 'lucide-react'
  ```

---

### Getting Help

#### Resources:
1. **Lovable Discord**: https://discord.com/channels/1119885301872070706/1280461670979993613
2. **Lovable Docs**: https://docs.lovable.dev/
3. **React Docs**: https://react.dev/
4. **Tailwind Docs**: https://tailwindcss.com/docs
5. **Vite Docs**: https://vitejs.dev/
6. **PHP Manual**: https://www.php.net/manual/

#### When Asking for Help:
1. **Describe the problem**: What are you trying to do?
2. **Show error messages**: Copy exact error text
3. **Share code**: Use code snippets or GitHub gists
4. **Environment info**:
   - OS (Windows/Mac/Linux)
   - Node version (`node --version`)
   - npm version (`npm --version`)
   - Browser and version
5. **What you tried**: List solutions you attempted

---

## Next Steps After Setup

### 1. Explore the Code
- Read through component files to understand structure
- Try modifying some text and see live updates
- Experiment with Tailwind classes

### 2. Customize the Design
- Edit `src/index.css` to change color scheme
- Modify `tailwind.config.ts` for theme changes
- Create your own components

### 3. Add Features
- Implement new filters
- Add favorite jobs functionality
- Create email notifications
- Build admin dashboard

### 4. Learn the Stack
- Complete React tutorial: https://react.dev/learn
- Learn TypeScript: https://www.typescriptlang.org/docs/
- Master Tailwind: https://tailwindcss.com/docs
- Understand PHP: https://www.php.net/manual/en/getting-started.php

### 5. Deploy Your App
- Build for production: `npm run build`
- Deploy to Vercel, Netlify, or custom server
- Set up domain name
- Configure SSL certificate

### 6. Contribute to Lovable
- Share your project in Discord
- Write tutorials for others
- Report bugs and suggest features
- Help other developers

---

## Maintenance and Updates

### Updating Dependencies
```bash
# Check for outdated packages
npm outdated

# Update all packages
npm update

# Update specific package
npm install package-name@latest
```

### Backup Strategy
1. **Use Git commits** regularly
2. **Push to GitHub** after significant changes
3. **Export database** weekly:
   ```bash
   # In phpMyAdmin: Export → SQL → Go
   # Or via command line:
   mysqldump -u root job_board > backup.sql
   ```
4. **Keep backups** of `.env` files (if created)

### Code Quality
- Run ESLint before commits: `npm run lint`
- Format code with Prettier
- Write comments for complex logic
- Follow naming conventions
- Keep components small and focused

---

## Success Checklist

After completing this guide, you should have:

- ✅ Node.js, npm, and Git installed
- ✅ VS Code installed with recommended extensions
- ✅ XAMPP installed with Apache and MySQL running
- ✅ Project cloned from GitHub
- ✅ npm dependencies installed (`node_modules/` exists)
- ✅ Database created and schema imported
- ✅ Backend files in XAMPP htdocs directory
- ✅ Dev server running on http://localhost:8080
- ✅ Application loading in browser without errors
- ✅ Can register and login successfully
- ✅ Can view and filter jobs
- ✅ Database shows data in phpMyAdmin
- ✅ Two-way sync working with Lovable via GitHub

**If all checked**: Congratulations! Your development environment is ready! 🎉

**If some missing**: Review the relevant sections above and troubleshoot specific issues.

---

## Document Information

- **Created**: For job board application transfer to local development
- **Covers**: Complete setup from prerequisites to deployment-ready environment
- **Skill Level**: Beginner-friendly with detailed explanations
- **Estimated Setup Time**: 1-2 hours (first time)
- **Last Updated**: Matches current project structure
- **Version**: 1.0.0

---

This comprehensive guide should enable anyone to transfer the Lovable project to VS Code and set up a fully functional local development environment. Keep this document for reference during development!
