# JobBoard - Complete Job Board Web Application

## Project Overview
A modern, full-stack job board web application built for exam submission. Connects job seekers with employers through an intuitive, responsive interface.

## 🚀 Features

### Authentication
- **User Registration**: Support for both job seekers and employers
- **Secure Login**: Password hashing with bcrypt and session management
- **Role-based Access**: Different dashboards and permissions for seekers vs employers
- **Token Authentication**: JWT-like sessions with expiration

### Job Management
- **Post Jobs**: Employers can create detailed job listings
- **Browse Jobs**: Anyone can view and search job listings
- **Job Details**: Comprehensive job information with application functionality
- **Manage Jobs**: Employers can edit/delete their own job postings

### Applications
- **Apply for Jobs**: Job seekers can apply with cover letters
- **Track Applications**: View application status and history
- **Prevent Duplicates**: Users cannot apply twice for the same job
- **Application Management**: Employers can view applications (future enhancement)

### User Experience
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Search & Filter**: Find jobs by title, company, location, and type
- **Modern UI**: Clean, professional design with smooth animations
- **Real-time Updates**: Immediate feedback for all user actions

## 🛠 Technology Stack

### Frontend
- **React 18** with Vite for development
- **TypeScript** for type safety
- **Tailwind CSS** for styling with custom design system
- **React Router DOM** for client-side routing
- **React Hooks** (useState, useEffect, custom hooks)
- **Fetch API** for backend communication
- **shadcn/ui** components for consistent UI

### Backend
- **PHP 8+** with procedural approach
- **MySQL** database with proper relationships
- **PDO** for database operations
- **CORS** enabled for local development
- **RESTful API** design

### Database Schema
```sql
- users (id, name, email, password, role, created_at)
- sessions (id, user_id, token, expires_at, created_at)
- jobs (id, title, company, location, type, description, salary, employer_id, created_at)
- applications (id, job_id, user_id, cover_letter, status, applied_at)
```

## 📁 Project Structure

```
job-board/
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn/ui components
│   │   ├── Header.tsx       # Navigation header
│   │   └── JobCard.tsx      # Job listing card
│   ├── contexts/
│   │   └── AuthContext.tsx  # Authentication context
│   ├── hooks/
│   │   └── useJobs.ts       # Custom hook for job management
│   ├── pages/
│   │   ├── Home.tsx         # Job listings with search
│   │   ├── Login.tsx        # User login
│   │   ├── Register.tsx     # User registration
│   │   ├── Dashboard.tsx    # User dashboard
│   │   ├── JobDetails.tsx   # Job details and application
│   │   └── PostJob.tsx      # Job posting form
│   ├── App.tsx              # Main app component
│   └── index.css            # Design system & styles
├── backend/
│   ├── config/
│   │   ├── database.php     # Database connection
│   │   └── cors.php         # CORS configuration
│   ├── auth/
│   │   ├── register.php     # User registration
│   │   ├── login.php        # User login
│   │   └── check.php        # Token verification
│   ├── jobs/
│   │   ├── list.php         # Get all jobs
│   │   ├── details.php      # Get job by ID
│   │   ├── create.php       # Create new job
│   │   └── delete.php       # Delete job
│   ├── applications/
│   │   ├── apply.php        # Submit job application
│   │   ├── my-applications.php  # Get user's applications
│   │   └── check.php        # Check if already applied
│   └── setup.sql            # Database schema & sample data
```

## 🎯 Exam Requirements Met

### Frontend Requirements ✅
- [x] Built with React + Vite
- [x] Uses React Hooks (useState, useEffect, custom hooks)
- [x] Implements React Router for navigation
- [x] Styled with Tailwind CSS
- [x] Event handling: onClick, onChange, onSubmit, onMouseEnter, onMouseLeave
- [x] Uses Fetch API (no Axios)

### Backend Requirements ✅
- [x] Built with PHP
- [x] Connects to MySQL database
- [x] User registration with bcrypt password hashing
- [x] Login with sessions/tokens
- [x] Full CRUD operations for jobs
- [x] Job application system linked to users

### Database Requirements ✅
- [x] Complete schema with all required tables
- [x] Foreign key relationships
- [x] Sample data included
- [x] Exportable as .sql file

## 🚀 Setup Instructions

### Prerequisites
- Node.js 18+ and npm
- PHP 8+ 
- MySQL (via XAMPP/Laragon)
- Web server (Apache via XAMPP/Laragon)

### Database Setup
1. Start XAMPP/Laragon and ensure MySQL is running
2. Open phpMyAdmin (http://localhost/phpmyadmin)
3. Import `backend/setup.sql` to create database and tables
4. Database will be created as `job_board` with sample data

### Backend Setup
1. Copy the `backend` folder to your web server directory:
   - XAMPP: `C:/xampp/htdocs/job-board-api/`
   - Laragon: `C:/laragon/www/job-board-api/`
2. Ensure the backend is accessible at `http://localhost/job-board-api/`

### Frontend Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start development server:
   ```bash
   npm run dev
   ```
3. Open http://localhost:8080

### Test Accounts
- **Employer**: employer@example.com / password
- **Job Seeker**: seeker@example.com / password

## 🎨 Design System

### Color Palette
- **Primary**: Professional blue (#3B82F6) for trust and reliability
- **Success**: Green (#10B981) for successful actions
- **Warning**: Orange (#F59E0B) for attention items
- **Destructive**: Red (#EF4444) for dangerous actions

### Key Features
- Responsive design system with mobile-first approach
- Custom gradients and shadows for modern appeal
- Semantic color tokens for consistency
- Accessible contrast ratios
- Smooth animations and transitions

## 📊 API Endpoints

### Authentication
- `POST /auth/register.php` - User registration
- `POST /auth/login.php` - User login  
- `GET /auth/check.php` - Verify token

### Jobs
- `GET /jobs/list.php` - Get all jobs
- `GET /jobs/details.php?id={id}` - Get job details
- `POST /jobs/create.php` - Create job (employers only)
- `DELETE /jobs/delete.php?id={id}` - Delete job (owner only)

### Applications
- `POST /applications/apply.php` - Submit application
- `GET /applications/my-applications.php` - Get user's applications
- `GET /applications/check.php?job_id={id}` - Check application status

## 🔒 Security Features
- Password hashing with PHP's password_hash()
- SQL injection prevention with prepared statements
- CORS properly configured for development
- Token-based authentication with expiration
- Role-based access control
- Input validation and sanitization

## 📱 Responsive Design
- Mobile-first approach with Tailwind CSS
- Adaptive layouts for all screen sizes
- Touch-friendly interactive elements
- Optimized performance on all devices

## 🎯 Future Enhancements
- Email notifications for applications
- File upload for resumes
- Advanced search filters
- Admin panel for moderation
- Company profiles
- Job recommendation system

## 📋 Exam Deliverables
1. ✅ Complete frontend source code (React + Vite + Tailwind)
2. ✅ Complete backend source code (PHP + MySQL)
3. ✅ Database export file (`backend/setup.sql`)
4. ✅ Setup documentation (this README)

## 🏆 Key Highlights
- **Modern Stack**: Latest React with TypeScript and modern PHP practices
- **Clean Architecture**: Modular, maintainable code structure
- **Production Ready**: Proper error handling, validation, and security
- **User Focused**: Intuitive UI/UX with excellent responsive design
- **Exam Compliant**: Meets all technical and functional requirements

## 📞 Support
For any setup issues or questions, please refer to this documentation or check the inline code comments for implementation details.

---
*Built with ❤️ for exam submission - demonstrating full-stack web development skills*