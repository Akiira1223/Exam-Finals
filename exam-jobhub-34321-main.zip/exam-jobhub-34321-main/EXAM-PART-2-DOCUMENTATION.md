# Exam Part 2 - New Features Documentation

## Overview
This document details all new features added for Part 2 of the exam, including custom hooks, OOP database implementation, event-driven programming, and CRUD operations with sorting/filtering.

---

## 1. Custom Hooks (11 Total)

### Existing Hooks:
1. **useAuth** (src/contexts/AuthContext.tsx)
   - Manages authentication state and operations
   - Functions: login, logout, register

2. **useJobs** (src/hooks/useJobs.ts)
   - Manages job listings and operations
   - Functions: fetchJobs, createJob, deleteJob

3. **use-mobile** (src/hooks/use-mobile.tsx)
   - Detects mobile screen sizes
   - Returns boolean for responsive design

### New Custom Hooks Added:

4. **useApplications** (src/hooks/useApplications.ts)
   - **Purpose**: Manages job applications for seekers
   - **Functions**:
     - `fetchApplications()`: Gets user's applications
     - `applyForJob(jobId, coverLetter)`: Submit new application
     - `checkApplicationStatus(jobId)`: Check if already applied
   - **State**: applications, loading, error

5. **useJobFilters** (src/hooks/useJobFilters.ts)
   - **Purpose**: Advanced filtering for job listings
   - **Functions**:
     - `updateFilter(key, value)`: Update specific filter
     - `resetFilters()`: Clear all filters
   - **Filters**: searchTerm, location, jobType, minSalary, maxSalary
   - **Returns**: filteredJobs, filterCount

6. **useJobSort** (src/hooks/useJobSort.ts)
   - **Purpose**: Sorting functionality for job listings
   - **Functions**:
     - `toggleSort(field)`: Toggle sort direction
     - `setSortField(field)`: Set sorting field
     - `setSortOrder(order)`: Set asc/desc
   - **Sort Fields**: title, company, location, salary, created_at

7. **useLocalStorage** (src/hooks/useLocalStorage.ts)
   - **Purpose**: Generic localStorage state management
   - **Functions**:
     - Returns: [value, setValue, removeValue]
   - **Features**: Automatic persistence, error handling

8. **useDebounce** (src/hooks/useDebounce.ts)
   - **Purpose**: Debounce values to optimize performance
   - **Parameters**: value, delay (default 500ms)
   - **Use Case**: Search inputs, API calls

9. **useDocumentTitle** (src/hooks/useDocumentTitle.ts)
   - **Purpose**: Update browser document title
   - **Parameters**: title, restoreOnUnmount
   - **Use Case**: SEO and user experience

10. **useClickOutside** (src/hooks/useClickOutside.ts)
    - **Purpose**: Detect clicks outside an element
    - **Parameters**: ref, handler function
    - **Use Case**: Close dropdowns, modals

11. **useKeyPress** (src/hooks/useKeyPress.ts)
    - **Purpose**: Detect specific key presses
    - **Parameters**: targetKey (e.g., 'Enter', 'Escape')
    - **Returns**: boolean keyPressed

12. **useWindowSize** (src/hooks/useWindowSize.ts)
    - **Purpose**: Track window dimensions
    - **Returns**: { width, height }
    - **Use Case**: Responsive behavior

13. **usePagination** (src/hooks/usePagination.ts)
    - **Purpose**: Pagination logic for lists
    - **Functions**:
      - `goToPage(page)`, `nextPage()`, `previousPage()`
      - `goToFirstPage()`, `goToLastPage()`
    - **Returns**: paginatedItems, currentPage, totalPages

14. **useFormValidation** (src/hooks/useFormValidation.ts)
    - **Purpose**: Form validation with rules
    - **Features**:
      - Required, minLength, maxLength, pattern, custom validators
      - Error tracking, touched fields
    - **Functions**: handleChange, handleBlur, validateAll, resetForm

15. **useAsync** (src/hooks/useAsync.ts)
    - **Purpose**: Handle async operations
    - **Returns**: { data, error, status, execute }
    - **Status**: idle, pending, success, error

---

## 2. Database - OOP Principles

### OOP Implementation in Backend

#### A. DatabaseConnection Class (backend/database/DatabaseConnection.php)
**Design Pattern**: Singleton Pattern
- **Purpose**: Single database connection instance
- **OOP Principles**:
  - **Encapsulation**: Private constructor, private properties
  - **Single Responsibility**: Only manages database connections
- **Methods**:
  - `getInstance()`: Get singleton instance
  - `getConnection()`: Get PDO connection
  - `beginTransaction()`, `commit()`, `rollback()`: Transaction management

#### B. BaseModel Class (backend/models/BaseModel.php)
**Design Pattern**: Active Record Pattern
- **OOP Principles**:
  - **Abstraction**: Abstract base class for all models
  - **Inheritance**: All models extend BaseModel
  - **Code Reusability**: Common CRUD operations
- **Methods** (Generic for all models):
  - `findById($id)`: Retrieve single record
  - `findAll($options)`: Retrieve all records with filters
  - `create($data)`: Insert new record
  - `update($id, $data)`: Update existing record
  - `delete($id)`: Delete record
  - `count($options)`: Count records with filters

#### C. JobModel Class (backend/models/JobModel.php)
**OOP Principles**:
- **Inheritance**: Extends BaseModel
- **Polymorphism**: Overrides base methods, adds specific methods
- **Methods**:
  - `getJobsWithEmployer($options)`: INNER JOIN with users table
  - `getJobsByEmployer($employerId)`: Employer-specific jobs
  - `getJobStatistics()`: Aggregation queries

#### D. ApplicationModel Class (backend/models/ApplicationModel.php)
**OOP Principles**:
- **Inheritance**: Extends BaseModel
- **Encapsulation**: Application-specific logic
- **Methods**:
  - `getApplicationsWithDetails($userId)`: INNER JOIN jobs + users
  - `getApplicationsForEmployer($employerId)`: Employer view
  - `updateStatus($id, $status)`: Update application status
  - `hasApplied($userId, $jobId)`: Check duplicate applications

---

## 3. Entity Relationships in Database

### Database Schema Relationships

#### Tables and Foreign Keys:
1. **users** (id, name, email, password, role)
   - Primary Key: id

2. **sessions** (id, user_id, token, expires_at)
   - Foreign Key: user_id → users.id (ON DELETE CASCADE)

3. **jobs** (id, title, company, location, type, description, salary, employer_id)
   - Foreign Key: employer_id → users.id (ON DELETE CASCADE)

4. **applications** (id, job_id, user_id, cover_letter, status)
   - Foreign Key: job_id → jobs.id (ON DELETE CASCADE)
   - Foreign Key: user_id → users.id (ON DELETE CASCADE)
   - Unique Constraint: (job_id, user_id) - Prevents duplicate applications

### Relationship Types:
- **One-to-Many**: User (employer) → Jobs
- **One-to-Many**: User (seeker) → Applications
- **One-to-Many**: Job → Applications
- **Many-to-One**: Sessions → User

---

## 4. INNER JOIN Implementation

### INNER JOIN Examples in Backend:

#### A. Jobs with Employer Details (backend/jobs/list-filtered.php)
```sql
SELECT j.*, u.name as employer_name, u.email as employer_email,
       COUNT(a.id) as applications_count
FROM jobs j
INNER JOIN users u ON j.employer_id = u.id
LEFT JOIN applications a ON j.id = a.job_id
GROUP BY j.id
```
**Purpose**: Get job listings with employer information and application counts

#### B. Applications with Job and Employer (ApplicationModel.php)
```sql
SELECT a.*, j.title as job_title, j.company, j.location,
       u.name as employer_name, u.email as employer_email
FROM applications a
INNER JOIN jobs j ON a.job_id = j.id
INNER JOIN users u ON j.employer_id = u.id
WHERE a.user_id = ?
```
**Purpose**: Get applications with complete job and employer details

#### C. Employer's Applications View (ApplicationModel.php)
```sql
SELECT a.*, j.title as job_title, j.company,
       u.name as applicant_name, u.email as applicant_email
FROM applications a
INNER JOIN jobs j ON a.job_id = j.id
INNER JOIN users u ON a.user_id = u.id
WHERE j.employer_id = ?
```
**Purpose**: Employers see applications to their jobs with applicant info

#### D. Authentication with User Verification
```sql
SELECT u.id, u.role 
FROM sessions s 
INNER JOIN users u ON s.user_id = u.id 
WHERE s.token = ? AND s.expires_at > NOW()
```
**Purpose**: Verify session and get user details in one query

---

## 5. CRUD Operations (Complete)

### CREATE Operations:
1. **Jobs** (backend/jobs/create.php)
   - Creates new job postings
   - Uses JobModel::create()

2. **Applications** (backend/applications/apply.php)
   - Submits job applications
   - Uses ApplicationModel::create()

3. **Users** (backend/auth/register.php)
   - Registers new users
   - Creates user and session

### READ Operations:
1. **Jobs List** (backend/jobs/list.php)
   - Retrieves all jobs
   - Uses JobModel::findAll()

2. **Jobs Filtered** (backend/jobs/list-filtered.php)
   - **NEW**: Advanced filtering and sorting
   - Parameters: type, location, search, salary range, sortBy, sortOrder
   - Uses JobModel::getJobsWithEmployer()

3. **Job Details** (backend/jobs/details.php)
   - Single job with full details
   - Uses JobModel::findById()

4. **Applications** (backend/applications/my-applications.php)
   - User's applications
   - Uses ApplicationModel::getApplicationsWithDetails()

5. **Application Check** (backend/applications/check.php)
   - Check if user already applied
   - Uses ApplicationModel::hasApplied()

6. **Job Statistics** (backend/jobs/statistics.php)
   - **NEW**: Aggregated job statistics
   - Uses JobModel::getJobStatistics()

### UPDATE Operations:
1. **Jobs** (backend/jobs/update.php)
   - **NEW**: Update existing job postings
   - Validates ownership (only job creator can update)
   - Uses JobModel::update()

2. **Application Status** (ApplicationModel.php)
   - Updates application status (pending/accepted/rejected)
   - Uses ApplicationModel::updateStatus()

### DELETE Operations:
1. **Jobs** (backend/jobs/delete.php)
   - Deletes job postings
   - Validates ownership
   - Uses JobModel::delete()

---

## 6. Sorting and Filtering

### Frontend Filtering (useJobFilters hook):
```typescript
Filters:
- searchTerm: Search in title, company, description
- location: Filter by location
- jobType: Filter by job type (full-time, part-time, etc.)
- minSalary: Minimum salary filter
- maxSalary: Maximum salary filter
```

### Frontend Sorting (useJobSort hook):
```typescript
Sort Fields:
- title: Alphabetical by job title
- company: Alphabetical by company name
- location: Alphabetical by location
- salary: Numerical by salary amount
- created_at: Chronological by posting date

Sort Order:
- asc: Ascending (A-Z, 0-9, oldest first)
- desc: Descending (Z-A, 9-0, newest first)
```

### Backend Filtering (list-filtered.php):
```php
Query Parameters:
- type: Filter by job type
- location: Search in location field (LIKE)
- search: Search in title, company, description (LIKE)
- min_salary: Minimum salary (>=)
- max_salary: Maximum salary (<=)
- sortBy: Sort field (default: created_at)
- sortOrder: ASC or DESC (default: DESC)
- limit: Pagination limit
- offset: Pagination offset
```

### SQL Filtering Example:
```sql
WHERE j.type = 'full-time'
  AND j.location LIKE '%New York%'
  AND (j.title LIKE '%developer%' OR j.company LIKE '%developer%')
  AND CAST(j.salary AS UNSIGNED) >= 50000
  AND CAST(j.salary AS UNSIGNED) <= 150000
ORDER BY j.created_at DESC
LIMIT 10 OFFSET 0
```

---

## 7. Event-Driven Programming

### Events Implemented:

#### A. onClick Events:
**Locations**:
- JobCard: Delete button
- Dashboard: Logout button
- JobDetails: Apply button
- All buttons throughout the app

**Example** (JobCard.tsx):
```tsx
<Button onClick={() => onDelete?.(job.id)}>Delete</Button>
```

#### B. onDoubleClick Events:
**Location**: JobCard component
**Purpose**: Double-click to open job in new tab
**Implementation**:
```tsx
<Card onDoubleClick={handleDoubleClick} title="Double-click to open in new tab">
```

#### C. onSubmit Events:
**Locations**:
- Login form
- Register form
- PostJob form
- Job application form

**Example** (Login.tsx):
```tsx
<form onSubmit={handleSubmit}>
```

#### D. onFocus Events:
**Locations**:
- Login: email, password inputs
- Register: name, email, password, confirmPassword inputs
- PostJob: all form inputs

**Purpose**: 
- Clear errors when user focuses
- Show visual feedback (ring highlight)

**Implementation**:
```tsx
<Input 
  onFocus={() => handleFocus('email')}
  className={focusedField === 'email' ? 'ring-2 ring-primary' : ''}
/>
```

#### E. onBlur Events:
**Locations**: Same as onFocus
**Purpose**:
- Validate fields when user leaves input
- Show inline validation errors

**Implementation**:
```tsx
<Input onBlur={() => handleBlur('email')} />

// Handler validates and shows errors
const handleBlur = (field: string) => {
  if (field === 'email' && email && !email.includes('@')) {
    setError('Please enter a valid email address');
  }
};
```

#### F. onKeyDown / onKeyPress Events:
**Locations**:
- Login password: Enter key submits form
- Register confirmPassword: Enter key submits form
- Home search: Enter key triggers search
- Home search/location: Escape key clears input

**Implementation**:
```tsx
<Input 
  onKeyDown={(e) => {
    if (e.key === 'Enter' && email && password) {
      handleSubmit(e as any);
    }
  }}
/>

<Input 
  onKeyDown={(e) => {
    if (e.key === 'Escape') {
      setSearchTerm('');
    }
  }}
/>
```

#### G. onLoad Event:
**Location**: Home.tsx
**Purpose**: Track when page fully loads
**Implementation**:
```tsx
useEffect(() => {
  const handleLoad = () => {
    setIsPageLoaded(true);
    console.log('Home page loaded successfully');
  };

  if (document.readyState === 'complete') {
    handleLoad();
  } else {
    window.addEventListener('load', handleLoad);
    return () => window.removeEventListener('load', handleLoad);
  }
}, []);
```

#### H. onChange Events:
**Locations**: All input fields, select dropdowns
**Examples**:
- Form inputs (text, email, password)
- Search filters (search term, location, job type)
- Radio buttons (user role selection)

---

## 8. Key Features Summary

### Custom Hooks: ✅ 15 total (exceeded 10+ requirement)
- Authentication, Jobs, Applications management
- Form validation, async operations
- UI utilities (debounce, click outside, key press, etc.)
- Filtering, sorting, pagination

### OOP Principles: ✅ Fully implemented
- **Singleton Pattern**: DatabaseConnection
- **Active Record Pattern**: BaseModel
- **Inheritance**: JobModel, ApplicationModel extend BaseModel
- **Encapsulation**: Private properties, protected methods
- **Abstraction**: Abstract base class
- **Polymorphism**: Method overriding

### Entity Relationships: ✅ Complete schema
- Four tables with proper foreign keys
- One-to-Many relationships
- Cascade deletes
- Unique constraints

### INNER JOIN: ✅ Multiple implementations
- Jobs with employers
- Applications with jobs and users
- Session authentication with users
- Aggregated data (applications count)

### CRUD Operations: ✅ All implemented
- **Create**: Jobs, Applications, Users
- **Read**: Jobs (filtered/sorted), Applications, Details
- **Update**: Jobs, Application status
- **Delete**: Jobs

### Sorting & Filtering: ✅ Advanced features
- Frontend hooks for client-side operations
- Backend endpoints with SQL filtering
- Multiple filter types (search, type, location, salary)
- Multiple sort fields and directions
- Pagination support

### Event-Driven: ✅ 8+ event types
- onClick, onDoubleClick, onSubmit
- onFocus, onBlur
- onKeyDown, onKeyPress
- onLoad
- onChange (forms, selects)

---

## 9. Testing the Features

### Test Custom Hooks:
1. Navigate through the application
2. Check browser console for useDocumentTitle updates
3. Test search debouncing in job listings
4. Test pagination on large job lists

### Test OOP Backend:
1. Create a new job (tests JobModel::create)
2. View jobs list (tests INNER JOIN)
3. Update a job (tests JobModel::update)
4. Delete a job (tests JobModel::delete)

### Test CRUD:
1. **Create**: Post a new job, apply to a job
2. **Read**: Browse jobs, view applications
3. **Update**: Edit job details, change application status
4. **Delete**: Remove a job posting

### Test Filtering/Sorting:
1. Use search box on homepage
2. Filter by location and job type
3. Apply salary range filters (in filtered endpoint)
4. Test sorting by different fields

### Test Events:
1. **onDoubleClick**: Double-click a job card
2. **onFocus/onBlur**: Click in/out of form inputs
3. **onKeyDown**: Press Enter in password field, Escape in search
4. **onSubmit**: Submit login/register forms
5. **onLoad**: Check console on page load

---

## 10. API Endpoints Reference

### New Endpoints Added:
1. `GET /jobs/list-filtered.php`
   - Advanced filtering and sorting
   - Query params: type, location, search, min_salary, max_salary, sortBy, sortOrder, limit, offset

2. `PUT /jobs/update.php`
   - Update job details
   - Body: { id, title, company, location, type, description, salary }
   - Requires authentication

3. `GET /jobs/statistics.php`
   - Job statistics with aggregation
   - Returns: total jobs, employers, salary stats, counts by type

---

## Conclusion

All requirements for Exam Part 2 have been successfully implemented:
- ✅ 10+ custom hooks (15 total)
- ✅ OOP principles in database layer
- ✅ Entity relationships with foreign keys
- ✅ INNER JOIN operations
- ✅ Complete CRUD operations
- ✅ Advanced sorting and filtering
- ✅ Comprehensive event-driven programming

The application now features a professional, modular architecture with reusable hooks, clean OOP backend structure, and rich user interactions through event handling.
